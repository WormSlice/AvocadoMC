#include "/lib/colors/skyColors.glsl"

// --- Estrellas fugaces por I11212 (CC BY) ---
#ifdef SHOOTING_STARS

float ShootingStarHash(vec2 x) {
    return fract(sin(dot(x, vec2(11.0, 57.0))) * 4000.0);
}

float ShootingStarCell(vec2 x, float time) {
    // Rotación del lienzo de las estrellas
    x *= mat2(cos(0.5), -sin(0.5), sin(0.5), cos(0.5));
    x.y += time;
    
    float shape = 1.0 - length(fract(x - vec2(0.0, 0.5)) - 0.5);
    x *= vec2(1.0, 0.085);
    vec2 fr = fract(x);
    
    // CORRECCIÓN: Se redujo de 0.01 a 0.003 para separar más las estrellas y evitar que salgan juntas
    float random = step(ShootingStarHash(floor(x)), 0.003); 
    float tall = (1.0 - (abs(fr.x - 0.5) + fr.y)) * random;
    
    return clamp(
        clamp((shape - random) * step(ShootingStarHash(floor(x + vec2(0.0, 0.05))), 0.003), 0.0, 1.0) + tall,
        0.0, 1.0
    );
}

vec3 GetShootingStars(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.0) return vec3(0.0);

    float speedMult = SHOOTING_STAR_SPEED * 0.01;
    float bloomMult = max(SHOOTING_STAR_BLOOM * 0.01, 0.12);
    float intensityMult = SHOOTING_STAR_I * 0.01;

    // Aurora-based tint, shifted cooler: less green, more blue
    vec3 auroraColor = mix(vec3(0.0, 3.0, 14.4), vec3(1.0, 10.0, 20.4), 0.5) / 14.4;
    auroraColor.g *= 0.62;
    vec3 starColor = auroraColor * vec3(SHOOTING_STAR_R, SHOOTING_STAR_G, SHOOTING_STAR_B) / vec3(100.0, 100.0, 100.0);

    // CORRECCIÓN: Usamos mod() para reiniciar el tiempo cada 3600 segundos (1 hora de juego real) 
    // Esto evita que los números enormes tras varias noches rompan la precisión del ruido (fract/sin)
    float safeTime = mod(frameTimeCounter, 3600.0);
    float time = safeTime * 16.0 * speedMult;
    
    // Se mantiene la escala pero el algoritmo interno ahora es más estricto con la densidad
    float starVal = ShootingStarCell(starCoord * 64.0, time);
    if (starVal <= 0.0) return vec3(0.0);

    // Sharp core, very subtle outer glow
    vec3 bloomExp = vec3(16.0, 26.0, 40.0) * bloomMult;
    vec3 col = pow(vec3(starVal), bloomExp) * starColor;

    float halo = pow(starVal, 6.0 / bloomMult);
    col += halo * starColor * 0.012 * bloomMult;

    float visibility = min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    visibility *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);

    return col * 115.0 * intensityMult * visibility;
}
#endif

float GetStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec2 GetStarCoord(vec3 viewPos, float sphereness) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);
    vec3 starCoord = wpos / (wpos.y + length(wpos.xz) * sphereness);
    starCoord.x += 0.006 * syncedTime;
    return starCoord.xz;
}

vec3 GetStars(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.0) return vec3(0.0);

    starCoord *= 0.15; 
    float starFactor = 2048.0; 
    starCoord = floor(starCoord * starFactor) / starFactor;

    float star = 1.0;
    star *= GetStarNoise(starCoord.xy);
    star *= GetStarNoise(starCoord.xy+0.1);
    star *= GetStarNoise(starCoord.xy+0.23);

    #if NIGHT_STAR_AMOUNT == 2
        star -= 0.7;
    #else
        star -= 0.6;
        star *= 0.65;
    #endif
    star = max0(star);
    star *= star;
    
    float starBrightness = star;
    if (star > 0.3) { 
        float bloomFactor = (star - 0.3) / 0.7; 
        star += star * bloomFactor * 0.7; 
    }

    float twinkle = sin(syncedTime * 2.0 + starCoord.x * 100.0) * 0.1 + 0.9;
    star *= twinkle;

    vec3 starColor = vec3(0.4, 0.6, 1.0); 

    star *= min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    star *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);

    vec2 starCoord2 = starCoord * 1.5 + vec2(0.3, 0.7);
    float star2 = 1.0;
    star2 *= GetStarNoise(starCoord2.xy);
    star2 *= GetStarNoise(starCoord2.xy + 0.15);
    star2 *= GetStarNoise(starCoord2.xy + 0.33);
    
    #if NIGHT_STAR_AMOUNT == 2
        star2 -= 0.75;
    #else
        star2 -= 0.65;
        star2 *= 0.6;
    #endif
    star2 = max0(star2);
    star2 *= star2;
    
    if (star2 > 0.25) { 
        float bloomFactor2 = (star2 - 0.25) / 0.75; 
        star2 += star2 * bloomFactor2 * 0.6; 
    }
    
    float twinkle2 = sin(syncedTime * 1.5 + starCoord2.x * 150.0) * 0.12 + 0.88;
    star2 *= twinkle2;
    
    star2 *= min1(VdotU * 2.5) * max0(1.0 - pow(abs(VdotS) * 1.002, 80.0));
    star2 *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.6 * sunVisibility);

    return 50.0 * star * starColor + 35.0 * star2 * starColor;
}

vec3 GetStarClusters(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.0) return vec3(0.0);
    
    starCoord *= 0.12; 
    float clusterFactor = 1024.0; 
    starCoord = floor(starCoord * clusterFactor) / clusterFactor;
    
    float cluster = GetStarNoise(starCoord.xy);
    cluster *= GetStarNoise(starCoord.xy + 0.3);
    cluster *= GetStarNoise(starCoord.xy + 0.7);
    
    cluster = max0(cluster - 0.75); 
    cluster *= cluster * 2.5; 
    
    if (cluster > 0.2) { 
        float clusterBloomFactor = (cluster - 0.2) / 0.8; 
        cluster += cluster * clusterBloomFactor * 0.5; 
    }
    
    vec2 clusterCoord2 = starCoord * 1.8 + vec2(0.4, 0.6);
    float cluster2 = GetStarNoise(clusterCoord2.xy);
    cluster2 *= GetStarNoise(clusterCoord2.xy + 0.25);
    cluster2 *= GetStarNoise(clusterCoord2.xy + 0.55);
    
    cluster2 = max0(cluster2 - 0.8);
    cluster2 *= cluster2 * 2.0;
    
    cluster *= min1(VdotU * 2.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 80.0));
    cluster2 *= min1(VdotU * 1.8) * max0(1.0 - pow(abs(VdotS) * 1.002, 70.0));
    
    cluster *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.6 * sunVisibility);
    cluster2 *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.7 * sunVisibility);
    
    return 25.0 * cluster * vec3(0.4, 0.6, 1.0) + 18.0 * cluster2 * vec3(0.4, 0.6, 1.0);
}