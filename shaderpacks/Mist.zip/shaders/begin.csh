// begin.csh — clears the voxel + light SSBOs at the start of each frame (Iris).
#version 430 compatibility
// #define VOXEL_LIGHTING  // voxel disabled (broken); passes now no-op
#include "/lib/voxel.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
// Voxel lighting is disabled (see #define above), so this pass is a no-op. Keep
// the dispatch minimal — a full 16^3 grid would launch ~2M idle threads/frame for
// nothing. Restore ivec3(16,16,16) if VOXEL_LIGHTING is ever re-enabled.
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {
#ifdef VOXEL_LIGHTING
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (!voxelInBounds(c)) return;
    int idx = voxelIndex(c);
    uVoxel[idx]  = 0u;
    uLightA[idx] = 0u;
    uLightB[idx] = 0u;
#endif
}
