#version 120

// ============================================================================
//  gbuffers_block.fsh — G-buffer writer only (block entities: chests, signs…)
//  Lit by the deferred composite pass, identical to terrain.
// ============================================================================

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldNormal;
varying vec4 worldTangent;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;

#include "/lib/gbuffer.glsl"

vec3 applyNormalMap(vec3 N, vec4 T, vec2 uv) {
    vec3 sampleN = texture2D(normals, uv).rgb;
    if (length(sampleN - vec3(0.5)) < 0.02) return normalize(N);

    vec3 nm;
    nm.xy = sampleN.xy * 2.0 - 1.0;
    nm.z  = sqrt(max(1.0 - dot(nm.xy, nm.xy), 0.0));

    vec3 tangent   = normalize(T.xyz);
    vec3 bitangent = normalize(cross(N, tangent) * T.w);
    mat3 tbn = mat3(tangent, bitangent, normalize(N));
    return normalize(tbn * nm);
}

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    vec3 N = applyNormalMap(worldNormal, worldTangent, texcoord);
    Material mat = getMaterial(specular, texcoord, color.rgb);

    /* DRAWBUFFERS:012 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(encodeNormalOct(N), mat.metallic, mat.smoothness);
    gl_FragData[2] = vec4(lmcoord.x, lmcoord.y, mat.emissive, 1.0);
}
