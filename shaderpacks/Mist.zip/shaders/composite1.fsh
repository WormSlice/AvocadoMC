#version 120

// ============================================================================
//  composite1.fsh — SSGI (screen-space global illumination / color bleeding)
//  Gathers nearby LIT surfaces (incl. emissive redstone/lapis) and adds their
//  color as one-bounce indirect light onto this pixel. This is the feasible
//  stand-in for voxel colored lighting: bright/colored surfaces tint neighbors.
// ============================================================================

uniform sampler2D colortex0;   // lit HDR scene (after water)
uniform sampler2D colortex1;   // rg = oct world normal
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

#include "/lib/gbuffer.glsl"

#define SSGI                          // toggle: screen-space color bleeding
#define SSGI_SAMPLES   8              // [8 12 16 20 28 36]
#define SSGI_RADIUS    1.6            // [1.0 1.6 2.2 2.6 3.0 4.0 5.5]
#define SSGI_STRENGTH  1.0            // [0.0 0.2 0.35 0.45 0.5 0.7 1.0 1.5]

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
vec3 hash33(vec3 p3) {
    p3 = fract(p3 * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yxz + 33.33);
    return fract((p3.xxy + p3.yxx) * p3.zyx);
}
vec3 viewFromDepth(vec2 uv, float d) {
    vec3 ndc = vec3(uv, d) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * vec4(ndc, 1.0);
    return v.xyz / v.w;
}

void main() {
    vec3  scene = texture2D(colortex0, texcoord).rgb;
    float depth = texture2D(depthtex0, texcoord).r;
    vec3  gi    = vec3(0.0);

#ifdef SSGI
    if (depth < 1.0) {
        vec3 vpos = viewFromDepth(texcoord, depth);
        vec3 n    = normalize(mat3(gbufferModelView) *
                              decodeNormalOct(texture2D(colortex1, texcoord).rg));
        float rnd = hash12(texcoord * vec2(viewWidth, viewHeight));

        for (int i = 0; i < SSGI_SAMPLES; i++) {
            vec3 d = normalize(hash33(vec3(texcoord, float(i) + rnd)) * 2.0 - 1.0);
            if (dot(d, n) < 0.0) d = -d;
            float r = SSGI_RADIUS * (0.2 + 0.8 * float(i) / float(SSGI_SAMPLES));
            vec3 sp = vpos + d * r;

            vec4 clip = gbufferProjection * vec4(sp, 1.0);
            if (clip.w <= 0.0001) continue;                  // behind/at camera plane -> skip (no streak)
            vec2 suv  = clip.xy / clip.w * 0.5 + 0.5;
            if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;

            float sd = texture2D(depthtex0, suv).r;
            if (sd >= 1.0) continue;
            vec3 svpos = viewFromDepth(suv, sd);

            vec3  toS  = svpos - vpos;
            float dist = length(toS);
            if (dist > SSGI_RADIUS * 1.5 || dist < 1e-3) continue;
            vec3 dir = toS / dist;

            float ndl = max(dot(n, dir), 0.0);                 // receiver faces emitter
            vec3 sN = normalize(mat3(gbufferModelView) *
                                decodeNormalOct(texture2D(colortex1, suv).rg));
            float emit  = max(dot(sN, -dir), 0.0);             // emitter faces back
            float atten = 1.0 / (1.0 + dist * dist);

            gi += texture2D(colortex0, suv).rgb * ndl * emit * atten;
        }
        gi *= SSGI_STRENGTH / float(SSGI_SAMPLES);
    }
#endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(scene + gi, 1.0);
}
