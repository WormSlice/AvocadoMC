#version 120

// ============================================================================
//  gbuffers_skybasic.fsh — physical sky.
//  Replaces the old procedural gradient with Rayleigh+Mie single scattering
//  (lib/atmosphere.glsl). Writes RAW HDR into colortex0; tonemapping/bloom are
//  done later in final.fsh. World-space sun/moon directions only.
// ============================================================================

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 cameraPosition;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform mat4 gbufferModelViewInverse;

varying vec3 viewDir;     // world-space view ray (from skybasic.vsh)
varying vec4 glcolor;

#include "/lib/atmosphere.glsl"

void main() {
    vec3 dir = normalize(viewDir);

    // View-space celestial positions -> world space.
    vec3 sunDir  = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    vec3 moonDir = normalize(mat3(gbufferModelViewInverse) * moonPosition);

    vec3 sky = getSkyColor(dir, sunDir, moonDir, rainStrength);

    // Volumetric cloud layer composited over the sky (replaces vanilla clouds,
    // which gbuffers_clouds now discards). Sky pixels only.
    vec4 clouds = renderCloudLayer(dir, cameraPosition, sunDir, rainStrength, frameTimeCounter);
    sky = mix(sky, clouds.rgb, clouds.a);

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(sky, 1.0);   // colortex0 (HDR)
}
