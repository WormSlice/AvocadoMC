// deferred1.fsh — VOXEL LIGHT RESOLVE (Iris, #version 430). For every opaque
// pixel, reconstruct its world position, push the sample point OFF the surface
// along its normal (so we read the lit AIR voxel, not the surface's own dark
// solid voxel), then trilinearly sample the propagated voxel light field (SSBO)
// -> colortex4. deferred2 reads this as colored, hard-occluded block light.
// With VOXEL_LIGHTING off it just writes black.
#version 430 compatibility

// #define VOXEL_LIGHTING  // voxel disabled (broken); passes now no-op

uniform sampler2D depthtex0;
uniform sampler2D colortex1;   // rg = octahedral WORLD normal
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform vec3 cameraPosition;

in vec2 texcoord;

// gbuffer.glsl: decodeNormalOct (must match the encoder exactly)
#include "/lib/gbuffer.glsl"
#include "/lib/voxel.glsl"

void main() {
    vec3 voxLight = vec3(0.0);

#ifdef VOXEL_LIGHTING
    float depth = texture(depthtex0, texcoord).r;
    if (depth < 1.0) {
        vec3 ndc = vec3(texcoord, depth) * 2.0 - 1.0;
        vec4 vw  = gbufferProjectionInverse * vec4(ndc, 1.0);
        vec3 viewPos = vw.xyz / vw.w;
        vec3 player  = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;

        // World-space surface normal. sampleVoxelLight offsets along N into the
        // lit air voxel AND rejects cells behind the surface plane, so light
        // can't bleed through a wall onto its shadowed back face.
        vec3 N = decodeNormalOct(texture(colortex1, texcoord).rg);
        vec3 surfAbs = player + cameraPosition;

        voxLight = sampleVoxelLight(surfAbs, cameraPosition, N);
    }
#endif

    /* DRAWBUFFERS:4 */
    gl_FragData[0] = vec4(voxLight, 1.0);
}
