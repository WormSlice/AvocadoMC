#version 120

// ============================================================================
//  gbuffers_terrain.fsh — G-buffer writer only.
//  All lighting (directional sun/moon, point block-lights, shadows, fog) is
//  performed in the deferred composite pass from this G-buffer. No lighting is
//  done here, and no camera-dependent shading is used.
// ============================================================================

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform float frameTimeCounter;   // ore-glow shimmer

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldNormal;
varying vec4 worldTangent;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;

#include "/lib/gbuffer.glsl"

// Apply a tangent-space normal map onto the world-space geometric normal.
vec3 applyNormalMap(vec3 N, vec4 T, vec2 uv) {
    vec3 sampleN = texture2D(normals, uv).rgb;
    if (length(sampleN - vec3(0.5)) < 0.02) return normalize(N); // no normal map

    vec3 nm;
    nm.xy = sampleN.xy * 2.0 - 1.0;
    nm.y  = -nm.y;   // Minecraft/labPBR use DirectX normals (green channel inverted)
    nm.z  = sqrt(max(1.0 - dot(nm.xy, nm.xy), 0.0));

    vec3 tangent   = normalize(T.xyz);
    vec3 bitangent = normalize(cross(N, tangent) * T.w);
    mat3 tbn = mat3(tangent, bitangent, normalize(N));
    return normalize(tbn * nm);
}

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    vec3 N = applyNormalMap(worldNormal, worldTangent, texcoord);
    Material mat = getMaterial(specular, texcoord, color.rgb);

    // ---- Colored self-emission from block id --------------------------------
    //  Even on vanilla packs (no specular map) these blocks glow in their own
    //  texture color, because emission in the deferred pass is albedo * emissive.
    //  10010 = real light sources (full glow), 10011 = decorative glow blocks.
    if (blockId > 10009.5 && blockId < 10010.5) {
        mat.emissive = max(mat.emissive, 0.28);   // strong sources: glow but keep texture
    } else if (blockId > 10010.5 && blockId < 10011.5) {
        // Decorative glow (redstone/lapis). Boosted so the block visibly emits
        // its OWN color and SSGI has a saturated source to bleed onto neighbors
        // (this is the normal-path "redstone -> red light / lapis -> blue light").
        mat.emissive = max(mat.emissive, 0.34);
    } else if (blockId > 10011.5 && blockId < 10012.5) {
        // ---- Ore mineral glow ----------------------------------------------
        //  Only the SATURATED (colored) mineral flecks self-illuminate; the grey
        //  host stone has near-zero saturation and stays dark. So diamond glows
        //  cyan, redstone red, lapis blue, gold/copper warm, emerald green, while
        //  the surrounding stone reads normally. SSGI then bleeds that colored
        //  emission onto neighbouring blocks (the "color bleeding" glow).
        float mx  = max(max(color.r, color.g), color.b);
        float mn  = min(min(color.r, color.g), color.b);
        float sat = (mx - mn) / max(mx, 1e-3);
        float mineral = smoothstep(0.28, 0.62, sat);

        // Gentle per-fleck shimmer so the glow sparkles instead of sitting flat.
        // Keyed to a coarse world-space cell so nearby flecks twinkle out of sync.
        vec3  cell    = floor(worldPos * 6.0);
        float phase   = dot(cell, vec3(0.7, 1.3, 1.7));
        float shimmer = 0.90 + 0.10 * sin(frameTimeCounter * 2.5 + phase);

        mat.emissive = max(mat.emissive, mineral * 0.55 * shimmer);
    }

    /* DRAWBUFFERS:012 */
    gl_FragData[0] = color;                                              // albedo
    gl_FragData[1] = vec4(encodeNormalOct(N), mat.metallic, mat.smoothness);
    gl_FragData[2] = vec4(lmcoord.x, lmcoord.y, mat.emissive, 1.0);      // a=1 -> lit by deferred
}
