// ============================================================================
//  lib/tonemap.glsl
//  AgX filmic tonemap (minimal approximation) + exposure + color grading.
//  Input: linear HDR. Output of agxTonemap(): linear display-referred (apply
//  sRGB OETF afterwards). Pure functions, no uniforms.
// ============================================================================

#ifndef TONEMAP_GLSL
#define TONEMAP_GLSL

// ---- User grading knobs (driven by shaders.properties) ---------------------
#ifndef EXPOSURE
#define EXPOSURE          0.80   // [0.40 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.40 1.70 2.00]
#endif
#ifndef GRADE_CONTRAST
#define GRADE_CONTRAST    1.11   // [0.85 0.90 0.95 1.00 1.05 1.11 1.18 1.25 1.35]
#endif
#ifndef GRADE_SATURATION
#define GRADE_SATURATION  1.70   // [0.70 0.85 1.00 1.10 1.18 1.22 1.35 1.50 1.70]
#endif
#ifndef GRADE_VIBRANCE
#define GRADE_VIBRANCE    0.45   // [0.00 0.08 0.12 0.18 0.25 0.35 0.45] (high values tint near-white surfaces)
#endif

// AgX working-space matrices (Troy Sobotka / iolite minimal AgX).
const mat3 AGX_MAT = mat3(
    0.842479062253094,  0.0784335999999992, 0.0792237451477643,
    0.0423282422610123, 0.878468636469772,  0.0791661274605434,
    0.0423756549057051, 0.0784336,           0.879142973793104);

const mat3 AGX_MAT_INV = mat3(
     1.19687900512017,   -0.0980208811401368, -0.0990297440797205,
    -0.0528968517574562,  1.15190312990417,   -0.0989611768448433,
    -0.0529716355144438, -0.0980434501171241,  1.15107367264116);

// 6th-order polynomial approximation of the AgX sigmoid.
vec3 agxContrast(vec3 x) {
    vec3 x2 = x * x;
    vec3 x4 = x2 * x2;
    return + 15.5    * x4 * x2
           - 40.14   * x4 * x
           + 31.96   * x4
           - 6.868   * x2 * x
           + 0.4298  * x2
           + 0.1191  * x
           - 0.00232;
}

vec3 agxTonemap(vec3 col) {
    const float minEv = -12.47393;
    const float maxEv =   4.026069;

    col = max(col, 0.0);
    col = AGX_MAT * col;
    col = max(col, 1e-10);                  // avoid log2(<=0) -> NaN (black speckle)
    col = clamp(log2(col), minEv, maxEv);
    col = (col - minEv) / (maxEv - minEv);
    col = agxContrast(col);
    col = AGX_MAT_INV * col;
    col = pow(max(col, 0.0), vec3(2.2));   // back to linear display-referred
    return col;
}

// Reinhard-ish fallback when AgX is disabled.
vec3 reinhardTonemap(vec3 col) {
    col *= 1.0;
    return col / (col + vec3(1.0));
}

// Contrast / saturation / vibrance grade in linear space.
vec3 colorGrade(vec3 col) {
    // Contrast around mid-grey.
    col = (col - 0.18) * GRADE_CONTRAST + 0.18;
    col = max(col, 0.0);

    float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));

    // Saturation.
    col = mix(vec3(luma), col, GRADE_SATURATION);

    // Vibrance: boost saturation more for already-dull pixels.
    float sat = length(col - vec3(luma));
    col = mix(vec3(luma), col, 1.0 + GRADE_VIBRANCE * (1.0 - sat));

    return max(col, 0.0);
}

// sRGB OETF (display encode).
vec3 linearToSRGB(vec3 c) {
    c = clamp(c, 0.0, 1.0);
    return mix(c * 12.92,
               1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055,
               step(0.0031308, c));
}

#endif // TONEMAP_GLSL
