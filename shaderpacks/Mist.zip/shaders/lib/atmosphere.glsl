// ============================================================================
//  lib/atmosphere.glsl   (Stage 4 — atmosphere overhaul)
//
//  Physically-inspired single-scattering sky + aerial perspective + cloud light.
//
//  Two cost tiers, used in different places:
//    * atmosScatter / getSkyColor  — full Rayleigh+Mie raymarch. Runs ONLY for
//      sky-dome pixels (gbuffers_skybasic), so the loop cost is paid once per
//      sky pixel and never per opaque fragment.
//    * analyticSkyTint / applyAerialPerspective — closed-form (no loop). Cheap
//      enough to run per opaque pixel for true aerial perspective in the fog.
//
//  Pure functions only (no uniform declarations) so it can be included alongside
//  lib/lighting.glsl without symbol clashes. Callers pass world-space dirs.
// ============================================================================

#ifndef ATMOSPHERE_GLSL
#define ATMOSPHERE_GLSL

#ifndef PI
#define PI 3.14159265359
#endif

// ---- Config (overridable by defining before include; exposed as sliders) ---
#ifndef SKY_BRIGHTNESS
#define SKY_BRIGHTNESS   1.20   // [0.60 0.80 1.00 1.20 1.50 2.00] overall sky radiance
#endif
#ifndef MIE_STRENGTH
#define MIE_STRENGTH     1.00   // [0.50 0.75 1.00 1.50 2.00 3.00] haze / sun halo intensity
#endif
#ifndef NIGHT_BRIGHTNESS
#define NIGHT_BRIGHTNESS 0.75   // [0.50 0.75 1.00 1.50 2.00] night sky lift
#endif
#ifndef FOG_DENSITY
#define FOG_DENSITY      0.0020 // [0.0020 0.0035 0.0050 0.0070 0.0100 0.0150] aerial perspective thickness
#endif
#ifndef AERIAL_STRENGTH
#define AERIAL_STRENGTH  1.00   // [0.00 0.50 0.75 1.00 1.50 2.00] aerial perspective amount
#endif

// ---- Cloud config ----------------------------------------------------------
#ifndef CLOUD_COVERAGE
#define CLOUD_COVERAGE   0.60   // [0.30 0.40 0.50 0.60 0.70 0.80] base cloud amount (clear..overcast)
#endif
#ifndef CLOUD_DENSITY
#define CLOUD_DENSITY    2.00   // [0.50 0.75 1.00 1.30 1.60 2.00] opacity / thickness
#endif
#ifndef CLOUD_BRIGHTNESS
#define CLOUD_BRIGHTNESS 2.00   // [0.60 0.80 1.00 1.30 1.60 2.00] lit cloud radiance
#endif
#ifndef CLOUD_SPEED
#define CLOUD_SPEED      1.00   // [0.00 0.50 1.00 1.50 2.00 3.00] wind animation speed
#endif
#ifndef CLOUD_ALTITUDE
#define CLOUD_ALTITUDE   220.0  // [180.0 220.0 260.0 300.0 340.0 400.0] cloud layer base height (world Y)
#endif
#ifndef CLOUD_STEPS
#define CLOUD_STEPS      8      // [8 12 16 20 28 40] cloud raymarch steps (sky pixels only)
#endif
#ifndef CLOUD_THICKNESS
#define CLOUD_THICKNESS  220.0  // [60.0 90.0 120.0 160.0 220.0] vertical thickness (cumulus puffiness)
#endif
#define CLOUD_LIGHT_STEPS  3    // toward-sun shadow taps per sample

// Toggles (Iris/OptiFine option booleans).
#define CLOUDS   // enhanced layered, light-interacting clouds (off = vanilla-ish)
#define STARS    // procedural night stars

// Quality of the scattering raymarch (sky pixels only — cheap in practice).
#define ATMOS_I_STEPS 10   // primary view-ray samples
#define ATMOS_J_STEPS 4    // light-ray (optical depth) samples

// Ray / sphere intersection: nearest & farthest hit distances along rd.
vec2 atmosRSI(vec3 r0, vec3 rd, float sr) {
    float a = dot(rd, rd);
    float b = 2.0 * dot(rd, r0);
    float c = dot(r0, r0) - (sr * sr);
    float d = (b * b) - 4.0 * a * c;
    if (d < 0.0) return vec2(1e5, -1e5);
    d = sqrt(d);
    return vec2((-b - d) / (2.0 * a), (-b + d) / (2.0 * a));
}

// Core Rayleigh+Mie single scattering (after wwwtyro's public-domain model).
vec3 atmosScatter(vec3 r, vec3 r0, vec3 pSun, float iSun,
                  float rPlanet, float rAtmos, vec3 kRlh, float kMie,
                  float shRlh, float shMie, float g) {
    pSun = normalize(pSun);
    r    = normalize(r);

    vec2 p = atmosRSI(r0, r, rAtmos);
    if (p.x > p.y) return vec3(0.0);
    p.y = min(p.y, atmosRSI(r0, r, rPlanet).x);
    float iStepSize = (p.y - p.x) / float(ATMOS_I_STEPS);

    float iTime = 0.0;
    vec3  totalRlh = vec3(0.0);
    vec3  totalMie = vec3(0.0);
    float iOdRlh = 0.0;
    float iOdMie = 0.0;

    float mu   = dot(r, pSun);
    float mumu = mu * mu;
    float gg   = g * g;
    float pRlh = 3.0 / (16.0 * PI) * (1.0 + mumu);
    float pMie = 3.0 / (8.0 * PI) * ((1.0 - gg) * (mumu + 1.0)) /
                 (pow(1.0 + gg - 2.0 * mu * g, 1.5) * (2.0 + gg));

    for (int i = 0; i < ATMOS_I_STEPS; i++) {
        vec3  iPos    = r0 + r * (iTime + iStepSize * 0.5);
        float iHeight = length(iPos) - rPlanet;
        float odRlh   = exp(-iHeight / shRlh) * iStepSize;
        float odMie   = exp(-iHeight / shMie) * iStepSize;
        iOdRlh += odRlh;
        iOdMie += odMie;

        float jStepSize = atmosRSI(iPos, pSun, rAtmos).y / float(ATMOS_J_STEPS);
        float jTime  = 0.0;
        float jOdRlh = 0.0;
        float jOdMie = 0.0;
        for (int j = 0; j < ATMOS_J_STEPS; j++) {
            vec3  jPos    = iPos + pSun * (jTime + jStepSize * 0.5);
            float jHeight = length(jPos) - rPlanet;
            jOdRlh += exp(-jHeight / shRlh) * jStepSize;
            jOdMie += exp(-jHeight / shMie) * jStepSize;
            jTime  += jStepSize;
        }

        vec3 attn = exp(-(kMie * (iOdMie + jOdMie) + kRlh * (iOdRlh + jOdRlh)));
        totalRlh += odRlh * attn;
        totalMie += odMie * attn;
        iTime    += iStepSize;
    }

    return iSun * (pRlh * kRlh * totalRlh + pMie * kMie * totalMie);
}

// Convenience wrapper with Earth-like constants. worldDir & sunDir are
// world-space unit vectors (y up). Returns HDR radiance.
vec3 atmosphereDaylight(vec3 worldDir, vec3 sunDir) {
    // Lift the ray a touch so the lower hemisphere mirrors the horizon instead
    // of returning a hard black planet shadow.
    worldDir.y = max(worldDir.y, -0.05);
    return atmosScatter(
        worldDir,
        vec3(0.0, 6372e3, 0.0),
        sunDir,
        22.0,                                   // sun intensity
        6371e3, 6471e3,
        vec3(5.5e-6, 13.0e-6, 22.4e-6),         // Rayleigh coeff (RGB)
        21e-6 * MIE_STRENGTH,                   // Mie coeff (haze)
        8e3, 1.2e3,                             // scale heights
        0.758);                                 // Mie anisotropy
}

// ----------------------------------------------------------------------------
//  Procedural stars (cheap hashed grid — only meaningful at night).
// ----------------------------------------------------------------------------
float starField(vec3 dir) {
#ifdef STARS
    // Quantise the direction into a coarse grid; one candidate star per cell.
    vec3 g = dir * 90.0;
    vec3 id = floor(g);
    vec3 fp = fract(g) - 0.5;
    float h = fract(sin(dot(id, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    // Only ~6% of cells host a star; sparkle by squared radial falloff.
    float present = step(0.94, h);
    float d = 1.0 - clamp(dot(fp, fp) * 6.0, 0.0, 1.0);
    return present * d * d;
#else
    return 0.0;
#endif
}

// Full sky: day scattering blended into a night sky, with sun & moon glints,
// twilight ozone tint, multi-scatter horizon lift and stars.
//  worldDir : view ray (world space, normalized)
//  sunDir   : world-space direction TO the sun
//  moonDir  : world-space direction TO the moon (usually -sunDir)
//  rain     : rainStrength [0,1] (greys & flattens the sky)
vec3 getSkyColor(vec3 worldDir, vec3 sunDir, vec3 moonDir, float rain) {
    worldDir = normalize(worldDir);
    sunDir   = normalize(sunDir);
    moonDir  = normalize(moonDir);

    float sunUp  = smoothstep(-0.10, 0.18, sunDir.y);   // 0 night, 1 day
    float lowSun = (1.0 - smoothstep(0.02, 0.28, sunDir.y)) * sunUp; // twilight band
    float horiz  = pow(1.0 - max(worldDir.y, 0.0), 5.0);

    // Daytime scattering (also produces dawn/dusk automatically).
    vec3 dayCol = atmosphereDaylight(worldDir, sunDir) * SKY_BRIGHTNESS;

    // Twilight ozone: warm the horizon band toward the sun at low sun angles.
    // Was pushing dayCol *1.4 (plus adding more ozone tint) across the whole
    // horizon band near the sun -- at dusk that band covers most of the visible
    // sky, so it read as an overwhelming pink wash rather than a warm sunset tint.
    float mu = max(dot(worldDir, sunDir), 0.0);
    vec3 ozone = vec3(1.30, 0.55, 0.35);
    dayCol = mix(dayCol, dayCol * 1.15 + ozone * 0.22,
                 lowSun * horiz * pow(mu, 1.5) * 0.6);

    // Multi-scatter ambient lift: a touch of diffuse blue so the lower sky and
    // shadowed horizon are never crushed to black (single-scatter is too dark).
    dayCol += vec3(0.04, 0.07, 0.13) * sunUp * (0.5 + 0.5 * horiz);

    // Night sky: deep blue gradient + faint variation + stars.
    float up = clamp(worldDir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 nightCol = mix(vec3(0.020, 0.030, 0.060),
                        vec3(0.006, 0.010, 0.024), up) * NIGHT_BRIGHTNESS;
    nightCol += vec3(0.55, 0.62, 0.85) * starField(worldDir)
                * (1.0 - rain) * smoothstep(0.0, 0.2, worldDir.y);

    // Sun disk / glow. The disk used to be multiplied by 30x -- so bright that
    // bloom bled it into a huge pink/white wash across most of the sky (and
    // buried the volumetric god rays, which read as an ADDITIVE effect on top
    // of the sky, in contrast against it). Toned down to a bright-but-bounded
    // disk so bloom draws a believable glow instead of a wash, and the sky
    // around it has enough headroom left for the god rays to actually show.
    float sunCos  = dot(worldDir, sunDir);
    float sunDisk = smoothstep(0.9995, 0.9998, sunCos);
    float sunGlow = pow(max(sunCos, 0.0), 64.0);
    dayCol += vec3(2.2, 1.9, 1.5) * sunDisk * 8.0;
    dayCol += vec3(1.0, 0.65, 0.35) * sunGlow * 0.5 * MIE_STRENGTH;

    // Moon disk / glow (only meaningful at night).
    float moonCos  = dot(worldDir, moonDir);
    float moonDisk = smoothstep(0.9990, 0.9995, moonCos);
    float moonGlow = pow(max(moonCos, 0.0), 90.0);
    nightCol += vec3(0.55, 0.60, 0.75) * moonDisk * 6.0;
    nightCol += vec3(0.20, 0.24, 0.34) * moonGlow * 0.6;

    vec3 sky = mix(nightCol, dayCol, sunUp);

    // Rain: desaturate toward grey and dim.
    float l = dot(sky, vec3(0.2126, 0.7152, 0.0722));
    sky = mix(sky, vec3(l) * 0.6 + vec3(0.10, 0.11, 0.13), rain * 0.7);

    return max(sky, vec3(0.0));
}

// ----------------------------------------------------------------------------
//  CHEAP ANALYTIC SKY TINT  (for aerial perspective / fog — NO raymarch)
//  Closed-form approximation of the scattered sky color in a given direction.
//  Mirrors the dome's mood (blue zenith, pale horizon, warm low-sun) at a tiny
//  fraction of the cost so it can run per opaque pixel.
// ----------------------------------------------------------------------------
vec3 analyticSkyTint(vec3 worldDir, vec3 sunDir, float rain) {
    worldDir = normalize(worldDir);
    sunDir   = normalize(sunDir);

    float sunUp  = smoothstep(-0.12, 0.20, sunDir.y);               // 0 night .. 1 day
    float lowSun = (1.0 - smoothstep(0.02, 0.30, sunDir.y)) * sunUp; // warm band near horizon
    float horiz  = pow(1.0 - max(worldDir.y, 0.0), 3.5);            // horizon emphasis

    // Day gradient (kept in the same exposure band as the raymarched dome).
    vec3 zenithDay  = vec3(0.20, 0.42, 1.00);
    vec3 horizonDay = vec3(0.74, 0.88, 1.12);
    vec3 dayTint = mix(zenithDay, horizonDay, horiz) * SKY_BRIGHTNESS;

    // Warm scattering toward a low sun (sunrise / sunset).
    float mu = max(dot(worldDir, sunDir), 0.0);
    vec3 warm = vec3(1.35, 0.62, 0.30);
    dayTint = mix(dayTint, warm, lowSun * pow(mu, 3.0) * 0.85);
    dayTint = mix(dayTint, mix(dayTint, warm, 0.45), lowSun * horiz * 0.55);

    // Night gradient.
    vec3 nightTint = mix(vec3(0.020, 0.030, 0.060),
                         vec3(0.045, 0.060, 0.110), horiz) * NIGHT_BRIGHTNESS;

    vec3 tint = mix(nightTint, dayTint, sunUp);

    // Rain greys it toward overcast.
    float l = dot(tint, vec3(0.2126, 0.7152, 0.0722));
    tint = mix(tint, vec3(l) * 0.7 + vec3(0.10, 0.11, 0.13), rain * 0.75);
    return max(tint, vec3(0.0));
}

// ----------------------------------------------------------------------------
//  AERIAL PERSPECTIVE  (true distance fog)
//  Distant geometry fades toward the sky color in ITS OWN view direction, with
//  extra desaturation + blue-shift that grow with distance (Rayleigh out-
//  scatter). This is the single biggest "flat -> RTX" win and is cheap (uses
//  analyticSkyTint, no raymarch).
//    color     : lit scene color
//    playerPos : eye-relative world position of the fragment
//    sunDir    : world-space direction TO the sun
//    rain      : rainStrength [0,1]
//    far       : render distance (uniform)
// ----------------------------------------------------------------------------
vec3 applyAerialPerspective(vec3 color, vec3 playerPos, vec3 sunDir,
                            float rain, float far) {
    float dist = length(playerPos);
    vec3  dir  = playerPos / max(dist, 1e-4);

    // Exponential-squared extinction, gated to start past the near field.
    float d  = FOG_DENSITY * (1.0 + rain * 3.0);
    float ff = clamp(1.0 - exp(-d * d * dist * dist), 0.0, 0.92);
    ff *= smoothstep(far * 0.12, far * 0.85, dist);
    ff *= AERIAL_STRENGTH;
    if (ff <= 0.0) return color;

    vec3 skyTint = analyticSkyTint(dir, sunDir, rain);

    // Aerial desaturation + blue-shift: the farther it is, the more the residual
    // surface color loses saturation and gains the sky's blue.
    float aer = ff * ff;
    float l   = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(color, vec3(l), aer * 0.35);                  // desaturate
    color = mix(color, color * vec3(0.92, 0.97, 1.10), aer);  // blue shift

    return mix(color, skyTint, ff);
}

// ----------------------------------------------------------------------------
//  Shared sun/ambient colors for clouds (so clouds match the sky's mood without
//  pulling in the full lighting.glsl). sunDir is world-space dir TO the sun.
// ----------------------------------------------------------------------------
vec3 skySunColor(vec3 sunDir) {
    float h      = sunDir.y;
    float lowSun = 1.0 - smoothstep(0.0, 0.30, h);
    vec3  noon   = vec3(1.00, 0.97, 0.92);
    vec3  warm   = vec3(1.00, 0.58, 0.32);
    vec3  night  = vec3(0.45, 0.52, 0.72);
    vec3  day    = mix(noon, warm, lowSun);
    float dayF   = smoothstep(-0.08, 0.10, h);
    return mix(night, day, dayF);
}

// ----------------------------------------------------------------------------
//  VOLUMETRIC CLOUDS  (sky-pass only — true 3D cumulus)
//
//  Real ray-marched 3D clouds: density is sampled from a 3D FBM noise field
//  (NOT a flat 2D layer), shaped vertically into rounded cumulus and eroded at
//  the edges by higher-frequency detail for the cauliflower silhouette. Lighting
//  uses a toward-sun shadow march (Beer-Powder self-shadowing) + Henyey-
//  Greenstein forward scatter for the silver lining and bright sun-side. Runs
//  ONLY on sky pixels in gbuffers_skybasic, so cost is bounded.
// ----------------------------------------------------------------------------

// 3D hash + value noise (cheap, GLSL120-safe).
float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}
float valueNoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash13(i + vec3(0,0,0)), n100 = hash13(i + vec3(1,0,0));
    float n010 = hash13(i + vec3(0,1,0)), n110 = hash13(i + vec3(1,1,0));
    float n001 = hash13(i + vec3(0,0,1)), n101 = hash13(i + vec3(1,0,1));
    float n011 = hash13(i + vec3(0,1,1)), n111 = hash13(i + vec3(1,1,1));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
               mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}
// 3-octave 3D FBM, normalized to ~[0,1]. (3 octaves is plenty once the march
// adds 2 erosion octaves on top — dropping the 4th octave is a big perf win.)
float fbm3(vec3 p) {
    float n = 0.0, a = 0.5;
    n += valueNoise3(p) * a; a *= 0.5; p *= 2.03;
    n += valueNoise3(p) * a; a *= 0.5; p *= 2.02;
    n += valueNoise3(p) * a;
    return n / 0.875;
}

// Henyey-Greenstein phase (forward scatter -> silver lining / bright sun side).
float hgPhase(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(max(1.0 + g2 - 2.0 * g * c, 1e-4), 1.5));
}

// Linear remap with clamp (the core of realistic cloud density shaping).
float remap(float v, float lo, float hi, float nlo, float nhi) {
    return nlo + clamp((v - lo) / max(hi - lo, 1e-4), 0.0, 1.0) * (nhi - nlo);
}

// 3D cumulus density at world position wp. lod=true uses only the base shape
// (cheap, for the toward-sun light march); full path adds 2 erosion octaves.
float cloudVolumeDensity(vec3 wp, float coverage, float time, bool lod) {
    float bottom = CLOUD_ALTITUDE;
    float hFrac  = clamp((wp.y - bottom) / CLOUD_THICKNESS, 0.0, 1.0);

    // Cumulus vertical profile: rounded base, narrowing rounded top.
    float heightGrad = smoothstep(0.0, 0.12, hFrac) * smoothstep(1.0, 0.28, hFrac);
    if (heightGrad <= 0.0) return 0.0;

    vec3 wind = vec3(time * 0.5 * CLOUD_SPEED, 0.0, time * 0.18 * CLOUD_SPEED);

    // Large-scale "weather map": varies coverage across the sky so clouds clump
    // into masses with clear gaps between them, instead of a uniform field. It is
    // very low frequency, so a single noise tap (not full FBM) is enough — cheap.
    float region = valueNoise3(vec3(wp.x, wp.z, time * 6.0) * 0.00045 + 4.0);
    float cov = mix(0.64, 0.26, coverage) - (region - 0.5) * 0.40;

    // Base billow shape.
    vec3  p    = (wp + wind) * 0.0016;
    float base = fbm3(p);
    float d    = remap(base, cov, 1.0, 0.0, 1.0) * heightGrad;
    if (d <= 0.0) return 0.0;

    // Slightly denser toward the base (mass settles low) -> flat-ish bottoms.
    d *= mix(0.55, 1.0, 1.0 - hFrac);

    if (lod) return d;

    // Edge erosion, two octaves: inverted (billow) noise carves rounded lumps,
    // then fine detail frays the very edges into wisps -> cauliflower cumulus.
    float det1 = fbm3(p * 5.3 + 7.0);
    d = remap(d, (1.0 - det1) * 0.42, 1.0, 0.0, 1.0);
    float det2 = fbm3(p * 15.0 + vec3(wind.x * 0.4, 0.0, 0.0) + 19.0);
    d = remap(d, det2 * 0.22, 1.0, 0.0, 1.0);

    return clamp(d, 0.0, 1.0);
}

// Dither hash for de-banding the march start.
float cloudJitter(vec3 dir) {
    return fract(sin(dot(dir.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

// Returns cloud color + coverage alpha for a view direction.
vec4 renderCloudLayer(vec3 dir, vec3 camPos, vec3 sunDir, float rain, float time) {
#ifndef CLOUDS
    return vec4(0.0);
#else
    if (dir.y < 0.015) return vec4(0.0);   // at/below horizon: skip (also avoids /0)

    float bottom = CLOUD_ALTITUDE;
    float top    = CLOUD_ALTITUDE + CLOUD_THICKNESS;
    float tB = (bottom - camPos.y) / dir.y;
    float tT = (top    - camPos.y) / dir.y;
    float tStart = max(min(tB, tT), 0.0);
    float tEnd   = max(tB, tT);
    if (tEnd <= 0.0) return vec4(0.0);      // slab entirely behind the camera
    tEnd = min(tEnd, tStart + 2200.0);      // cap march length (grazing rays)
    float segLen = (tEnd - tStart) / float(CLOUD_STEPS);

    float coverage = clamp(CLOUD_COVERAGE + rain * 0.40, 0.0, 0.95);
    vec3  sunCol   = skySunColor(sunDir) * 1.6;   // HDR punch so lit tops pop
    float dayF     = smoothstep(-0.08, 0.12, sunDir.y);
    // Shaded base is a NEUTRAL grey (real cumulus undersides/cores are grey, lit
    // only by dull ambient — not blue), the lit fill stays a bright sky tint. The
    // grey base is what gives clouds believable dark-grey shadowed volume instead
    // of a uniform white/pink puff.
    vec3  ambLow   = mix(vec3(0.07, 0.09, 0.13), vec3(0.30, 0.32, 0.35), dayF); // neutral-grey shaded base
    vec3  ambHigh  = mix(vec3(0.20, 0.25, 0.36), vec3(0.66, 0.74, 0.88), dayF); // lit sky fill

    // View/sun phase: two-lobe HG (strong forward silver lining + soft back).
    float mu    = dot(dir, sunDir);
    float phase = mix(hgPhase(mu, 0.80), hgPhase(mu, -0.18), 0.4);

    float ls  = CLOUD_THICKNESS / float(CLOUD_LIGHT_STEPS);
    float jit = cloudJitter(dir);
    float transmittance = 1.0;
    vec3  scatter       = vec3(0.0);

    // Empty-space skipping: advance fast through clear sky (cheap density test,
    // no light march), and only take the full lit step inside a cloud. This is
    // where most of the speedup comes from — empty sky pixels barely cost.
    float t = tStart + segLen * jit;
    for (int i = 0; i < CLOUD_STEPS && t < tEnd; i++) {
        vec3  wp = camPos + dir * t;
        float dens = cloudVolumeDensity(wp, coverage, time, false) * CLOUD_DENSITY;
        if (dens <= 0.001) { t += segLen * 1.6; continue; }   // skip empty space

        t += segLen;
        float hFrac = clamp((wp.y - CLOUD_ALTITUDE) / CLOUD_THICKNESS, 0.0, 1.0);

        // Toward-sun shadow march (self-shadowing -> 3D form & dark cores).
        float lightDens = 0.0;
        for (int j = 1; j <= CLOUD_LIGHT_STEPS; j++)
            lightDens += cloudVolumeDensity(wp + sunDir * (float(j) * ls), coverage, time, true);

        // Multiple-scattering approximation: sum of Beer lobes with decreasing
        // extinction (deep cloud still glows softly instead of going flat black).
        float ms = 0.0, a = 1.0, b = 1.0;
        for (int o = 0; o < 3; o++) { ms += a * exp(-lightDens * b * 1.1); a *= 0.5; b *= 0.35; }
        float powder = 1.0 - exp(-lightDens * 2.0);  // powder-sugar dark edges

        // Direct sun (phase + multi-scatter + powder) and height-graded ambient.
        vec3 sunLight = sunCol * ms * (1.0 + dayF) * (0.25 + phase) * mix(0.5, 1.0, powder);
        vec3 ambient  = mix(ambLow, ambHigh, hFrac);
        vec3 lightCol = ambient + sunLight;

        float stepT = exp(-dens * segLen * 0.085);   // Beer extinction along view
        scatter      += transmittance * (1.0 - stepT) * lightCol;
        transmittance *= stepT;
        if (transmittance < 0.02) break;
    }

    float alpha = (1.0 - transmittance) * smoothstep(0.015, 0.09, dir.y); // soft horizon fade

    // Overcast greys/darkens the deck.
    float l = dot(scatter, vec3(0.2126, 0.7152, 0.0722));
    scatter = mix(scatter, vec3(l) * 0.55 + vec3(0.06, 0.07, 0.09), rain * 0.6);

    return vec4(scatter * CLOUD_BRIGHTNESS, clamp(alpha, 0.0, 1.0));
#endif
}

#endif // ATMOSPHERE_GLSL
