// ============================================================================
//  lib/voxel.glsl  (Iris-only, #version 430+)
//  Voxel-based colored block light with HARD occlusion. Stores a player-centred
//  block-aligned voxel volume in SSBOs: occupancy+emitter (uVoxel) and a
//  ping-ponged light field (uLightA/uLightB). Solid non-emitter voxels block
//  light entirely; emitter voxels inject their color; propagation spreads it.
//  Only included by #version 430 programs (shadow voxelize, prepare*.csh,
//  deferred1 resolve). Everything is wrapped in VOXEL_LIGHTING.
// ============================================================================

#ifndef VOXEL_GLSL
#define VOXEL_GLSL

#ifdef VOXEL_LIGHTING

#ifndef VOXEL_RESOLUTION
#define VOXEL_RESOLUTION 128        // volume edge (blocks), player-centred
#endif
#ifndef VOXEL_FALLOFF
#define VOXEL_FALLOFF 0.84          // [0.78 0.82 0.84 0.87 0.90 0.93] per-voxel light attenuation
#endif
#ifndef VOXEL_EMITTER_BRIGHT
#define VOXEL_EMITTER_BRIGHT 3.5    // emitter seed intensity (lower = less blowout near lights)
#endif

// One-bounce colored GI: matte (non-emitter) solid blocks re-emit a fraction of
// the light hitting them, tinted by their own albedo. This is what makes a
// bright block spill colored light onto the dull blocks around it. Toggleable
// (off = original direct-only voxel light, a bit cheaper).
#define VOXEL_BOUNCE
#ifndef VOXEL_BOUNCE_STRENGTH
#define VOXEL_BOUNCE_STRENGTH 0.35  // [0.00 0.20 0.35 0.50 0.70 1.00] matte bounce amount
#endif

#define VOXEL_LIGHT_MAX 8.0         // packing range for the light field

layout(std430, binding = 0) buffer VoxelBuf  { uint uVoxel[];  };  // occupancy + emitter/albedo
layout(std430, binding = 1) buffer LightABuf { uint uLightA[]; };  // light ping
layout(std430, binding = 2) buffer LightBBuf { uint uLightB[]; };  // light pong

const uint VOXEL_SOLID_BIT   = 0x80000000u;
const uint VOXEL_EMITTER_BIT = 0x40000000u;

int  voxelIndex(ivec3 c) {
    return c.x + c.y * VOXEL_RESOLUTION + c.z * (VOXEL_RESOLUTION * VOXEL_RESOLUTION);
}
bool voxelInBounds(ivec3 c) {
    return all(greaterThanEqual(c, ivec3(0))) && all(lessThan(c, ivec3(VOXEL_RESOLUTION)));
}
// Block-aligned, camera-snapped voxel coordinate of an ABSOLUTE world position.
ivec3 worldToVoxel(vec3 worldAbs, vec3 cameraPos) {
    ivec3 origin = ivec3(floor(cameraPos)) - VOXEL_RESOLUTION / 2;
    return ivec3(floor(worldAbs)) - origin;
}

// ---- voxel packing ---------------------------------------------------------
//  bit 31 = solid, bit 30 = emitter (true light source),
//  bits 0-23 = color: emitter EMISSION color for emitters, block ALBEDO for
//  matte reflectors (used by the bounce). The explicit emitter bit lets a matte
//  block carry a (non-zero) albedo without being mistaken for a light source.
uint packVoxel(bool solid, bool emitter, vec3 col) {
    uvec3 e = uvec3(clamp(col, 0.0, 1.0) * 255.0 + 0.5);
    uint v = (e.r << 16) | (e.g << 8) | e.b;
    if (solid)   v |= VOXEL_SOLID_BIT;
    if (emitter) v |= VOXEL_EMITTER_BIT;
    return v;
}
bool voxelSolid(uint v)     { return (v & VOXEL_SOLID_BIT)   != 0u; }
bool voxelIsEmitter(uint v) { return (v & VOXEL_EMITTER_BIT) != 0u; }
vec3 voxelColor(uint v) {
    return vec3(float((v >> 16) & 0xFFu), float((v >> 8) & 0xFFu), float(v & 0xFFu)) / 255.0;
}
// A blocker is a solid block that is NOT a light source: it stops direct light
// (and, with VOXEL_BOUNCE, re-emits a dim albedo-tinted bounce instead).
bool voxelIsBlocker(uint v) { return voxelSolid(v) && !voxelIsEmitter(v); }

// ---- light field packing (RGB -> uint, 10 bits each) -----------------------
uint packLight(vec3 c) {
    uvec3 q = uvec3(clamp(c / VOXEL_LIGHT_MAX, 0.0, 1.0) * 1023.0 + 0.5);
    return (q.r << 20) | (q.g << 10) | q.b;
}
vec3 unpackLight(uint p) {
    return vec3(float((p >> 20) & 0x3FFu),
                float((p >> 10) & 0x3FFu),
                float( p        & 0x3FFu)) / 1023.0 * VOXEL_LIGHT_MAX;
}

// parity 0 -> read A / write B ; parity 1 -> read B / write A
uint readLightSrc(int parity, int idx)            { return (parity == 0) ? uLightA[idx] : uLightB[idx]; }
void writeLightDst(int parity, int idx, uint val) { if (parity == 0) uLightB[idx] = val; else uLightA[idx] = val; }

// One propagation step (called from a compute shader, one invocation per voxel).
// 2-voxel reach per step with a midpoint occlusion test, so N steps ~= 2N range.
void voxelPropagate(int parity) {
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (!voxelInBounds(c)) return;
    int idx = voxelIndex(c);
    uint vox = uVoxel[idx];

    ivec3 dirs[6];
    dirs[0] = ivec3( 1, 0, 0); dirs[1] = ivec3(-1, 0, 0);
    dirs[2] = ivec3( 0, 1, 0); dirs[3] = ivec3( 0,-1, 0);
    dirs[4] = ivec3( 0, 0, 1); dirs[5] = ivec3( 0, 0,-1);

    // incAir   : light arriving through transparent (air/emitter) neighbours.
    // incBounce: dim light re-emitted by matte (blocker) neighbours.
    vec3 incAir    = vec3(0.0);
    vec3 incBounce = vec3(0.0);

    for (int i = 0; i < 6; i++) {
        ivec3 n1 = c + dirs[i];
        if (!voxelInBounds(n1)) continue;
        int  i1     = voxelIndex(n1);
        bool block1 = voxelIsBlocker(uVoxel[i1]);
        vec3 l1     = unpackLight(readLightSrc(parity, i1));

        if (!block1) {
            incAir = max(incAir, l1 * VOXEL_FALLOFF);
            ivec3 n2 = c + dirs[i] * 2;                       // 2-step only through air
            if (voxelInBounds(n2)) {
                int i2 = voxelIndex(n2);
                if (!voxelIsBlocker(uVoxel[i2]))
                    incAir = max(incAir, unpackLight(readLightSrc(parity, i2)) * (VOXEL_FALLOFF * VOXEL_FALLOFF));
            }
        }
#ifdef VOXEL_BOUNCE
        else {
            incBounce = max(incBounce, l1 * VOXEL_FALLOFF);   // read the blocker's bounce
        }
#endif
    }

    // Matte solid cell: re-emit an albedo-tinted bounce of the AIR light hitting
    // it (computed from non-blocker neighbours only, so no feedback loop), else
    // it simply blocks (writes 0).
    if (voxelIsBlocker(vox)) {
#ifdef VOXEL_BOUNCE
        writeLightDst(parity, idx, packLight(voxelColor(vox) * incAir * VOXEL_BOUNCE_STRENGTH));
#else
        writeLightDst(parity, idx, 0u);
#endif
        return;
    }

    // Transparent / emitter cell: emitter re-seed + best of direct + bounce.
    vec3 best = vec3(0.0);
    if (voxelIsEmitter(vox)) best = voxelColor(vox) * VOXEL_EMITTER_BRIGHT;
    best = max(best, incAir);
#ifdef VOXEL_BOUNCE
    best = max(best, incBounce);
#endif

    writeLightDst(parity, idx, packLight(best));
}

// Sample the final (A) light field for a surface point. `surfAbs` is the actual
// surface world position and `N` its world normal. We push the sample off the
// face along N, then trilinearly gather the 8 surrounding voxels with TWO leak
// guards:
//   (1) BLOCKER-AWARE: skip solid non-emitter cells (no self-darkening).
//   (2) PLANE REJECT: skip any cell whose center is behind the surface plane.
//       This is the real fix for light bleeding THROUGH a 1-block wall — the lit
//       air cell on the far side of the wall is behind the plane, so it can
//       never contribute to this (shadowed) face.
vec3 sampleVoxelLight(vec3 surfAbs, vec3 cameraPos, vec3 N) {
    vec3 origin   = floor(cameraPos) - float(VOXEL_RESOLUTION / 2);
    vec3 sampleAbs = surfAbs + N * 0.6;          // push into the lit air voxel
    vec3 vp   = sampleAbs - origin;              // voxel-space position
    vec3 base = floor(vp - 0.5);
    vec3 f    = vp - 0.5 - base;

    vec3  sum  = vec3(0.0);
    float wsum = 0.0;
    for (int i = 0; i < 8; i++) {
        ivec3 off = ivec3(i & 1, (i >> 1) & 1, (i >> 2) & 1);
        ivec3 c = ivec3(base) + off;
        if (!voxelInBounds(c)) continue;
        uint vox = uVoxel[voxelIndex(c)];
        if (voxelIsBlocker(vox)) continue;       // (1) skip opaque occluders

        // (2) reject cells behind the surface plane (through-wall leak guard).
        vec3 cellCenter = origin + vec3(c) + 0.5;
        if (dot(cellCenter - surfAbs, N) < 0.05) continue;

        float w = ((off.x == 1) ? f.x : 1.0 - f.x)
                * ((off.y == 1) ? f.y : 1.0 - f.y)
                * ((off.z == 1) ? f.z : 1.0 - f.z);
        sum  += unpackLight(uLightA[voxelIndex(c)]) * w;
        wsum += w;
    }
    // Renorm floor 0.6 so a thin air sliver in a corner can't amplify into a
    // bright blocky spot.
    return sum / max(wsum, 0.6);
}

#endif // VOXEL_LIGHTING
#endif // VOXEL_GLSL
