// ============================================================================
//  lib/lighting.glsl
//  Shared deferred / forward lighting for VENC shaders (GLSL 120 / Iris·OptiFine)
//
//  This is the SINGLE source of truth for lighting. Both the deferred composite
//  pass (opaque G-buffer) and the forward translucent passes (water, hand) call
//  the exact same functions, so terrain, entities, transparent entities and PBR
//  materials are all shaded identically.
//
//  Lighting model:
//    * Sun / Moon : true directional light using the WORLD-SPACE light direction
//                   (derived from shadowLightPosition). Lambert diffuse +
//                   Cook-Torrance (GGX) specular BRDF. Never camera-direction
//                   based — only the view vector V feeds the specular half-vector
//                   as required by any physically based BRDF.
//    * Block light: a proper point light. A light position is reconstructed in
//                   world space from the block-light field gradient, the light
//                   direction is L = normalize(lightPos - worldPos), and the
//                   contribution is distance-attenuated (inverse-square style).
//    * Ambient    : hemispheric sky ambient + small constant fill.
//    * Shadows    : PCSS / Poisson PCF from distort.glsl, with colored shadows
//                   from shadowcolor0 for stained glass / water transmission.
// ============================================================================

#ifndef LIGHTING_GLSL
#define LIGHTING_GLSL

#include "/distort.glsl"
// atmosphere.glsl: analytic sky tint + aerial perspective
#include "/lib/atmosphere.glsl"
// underwater.glsl: Beer-Lambert absorption, caustics, murk (used only when submerged)
#include "/lib/underwater.glsl"

#ifndef PI
#define PI 3.14159265359
#endif

// ---- Tunables --------------------------------------------------------------
//  Diffuse uses the physically correct albedo/PI term, so light intensities are
//  scaled up accordingly to keep a natural exposure.
#define SUN_ILLUMINANCE     2.50   // [1.50 2.00 2.50 2.80 3.20 4.00 4.50 5.00] daytime sun intensity
#define MOON_ILLUMINANCE    0.20   // [0.20 0.30 0.40 0.55 0.70 0.90 1.20] nighttime moon intensity
#define BLOCKLIGHT_STRENGTH 1.20   // [2.00 3.00 4.20 5.00 6.00 7.50 9.00] point (torch) light intensity
#define BLOCKLIGHT_RANGE    8.0    // reconstructed reach of a block light, in blocks
#define SKY_AMBIENT_STRENGTH 0.70  // [0.20 0.40 0.50 0.60 0.70 0.85 1.00] hemispheric sky ambient
#define MIN_AMBIENT         0.10   // constant fill so caves / dark entities are never pure black
#define EMISSION_STRENGTH   1.00   // [1.00 1.60 2.20 2.80 3.50 4.50 6.00] emissive (specular.a) brightness

#define VOLUMETRIC_LIGHT           // toggle: ray-marched god rays / volumetric sun
#define VL_SAMPLES 6               // [6 8 12 16 20 24 32]
#define VL_STRENGTH 1.1            // [0.0 0.2 0.35 0.55 0.8 1.1 1.5]

// Ambient-occlusion multiplier set by the deferred pass from the SSAO buffer
// (forward passes leave it at 1.0). Mutable file-scope global avoids touching
// every computeSceneLighting() caller's signature.
float gAO = 1.0;

// First-person hand override: the hand sits at the camera, so projecting it into
// the world shadow map self-shadows it and drops all direct sun, leaving it dim.
// The hand pass sets this true so it receives full (unshadowed) sun gated only by
// its own sky-light. Everything else leaves it false.
bool gForceNoShadow = false;

// Voxel colored block light (Iris-only). deferred2 resolves the voxel light per
// pixel (from colortex4) and feeds it here; if set, it REPLACES the omni block
// light with colored, occluded light. Forward passes leave gUseVoxelLight false.
#ifdef VOXEL_LIGHTING
#ifndef VOXEL_BLOCKLIGHT_STRENGTH
#define VOXEL_BLOCKLIGHT_STRENGTH 1.30   // [0.4 0.7 1.0 1.3 1.7 2.2 3.0]
#endif
bool gUseVoxelLight   = false;
vec3 gVoxelBlockLight = vec3(0.0);
#endif

// ---- Uniforms (declared here so consumers don't redeclare them) ------------
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  shadowLightPosition;
uniform vec3  cameraPosition;

uniform int   worldTime;
uniform float rainStrength;
uniform float wetness;
uniform int   isEyeInWater;
uniform vec3  fogColor;        // OptiFine sets this to the biome's underwater tint when submerged
uniform float near;
uniform float far;

#ifndef FRAMETIME_DECLARED
#define FRAMETIME_DECLARED
uniform float frameTimeCounter;
#endif

uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform mat4  shadowModelView;
uniform mat4  shadowProjection;

uniform ivec2 eyeBrightnessSmooth;

// Shadow samplers
uniform sampler2D shadowtex0;       // opaque + translucent occluders
uniform sampler2D shadowtex1;       // opaque occluders only
uniform sampler2D shadowcolor0;     // colored shadow transmission

const bool shadowtex0Nearest   = true;
const bool shadowtex1Nearest   = true;
const bool shadowcolor0Nearest = false;

// ============================================================================
//  DAY / NIGHT
// ============================================================================

bool lightingIsDay() {
    return (worldTime >= 0 && worldTime <= 12000) || worldTime >= 23000;
}

// Smooth 0..1 day factor (0 = deep night, 1 = full day). Glides across the SAME
// dawn/dusk windows as getSunlightColor so day/night tints (ambient, underwater
// murk, caustics, god rays) fade in/out instead of snapping at a single tick —
// the boolean lightingIsDay() was what made the tint pop instantly.
float dayFactor() {
    float t = float(worldTime);
    if (t < 13500.0)  return 1.0 - smoothstep(12000.0, 13500.0, t);  // day -> dusk
    if (t < 22500.0)  return 0.0;                                    // night
    return smoothstep(22500.0, 24000.0, t);                          // dawn -> day
}

// Smooth day/night sunlight color (warm noon, cool night, dusk/dawn shifts).
vec3 getSunlightColor() {
    vec3 morning = vec3(1.00, 0.86, 0.70);
    vec3 noon    = vec3(1.00, 0.98, 0.95);
    vec3 evening = vec3(1.00, 0.68, 0.45);
    vec3 night   = vec3(0.55, 0.66, 0.92);

    // Narrow warm bands: reach NEUTRAL noon quickly after dawn and only warm
    // again late before dusk, so midday light (and open daytime interiors) stays
    // white instead of a salmon cast. Sunrise/sunset stay warm.
    float t = float(worldTime);
    if (t <= 6000.0) {
        return mix(morning, noon, smoothstep(0.0, 2500.0, t));
    } else if (t <= 12000.0) {
        return mix(noon, evening, smoothstep(10500.0, 12000.0, t));
    } else if (t <= 13500.0) {
        return mix(evening, night, smoothstep(12000.0, 13500.0, t));
    } else if (t <= 22500.0) {
        return night;
    } else {
        return mix(night, morning, smoothstep(22500.0, 24000.0, t));
    }
}

// Cool hemispheric sky ambient color (also warms at dusk/dawn).
vec3 getSkyAmbientColor() {
    vec3 dayAmb   = vec3(0.66, 0.76, 0.92);   // slightly desaturated so white reads clean
    vec3 nightAmb = vec3(0.14, 0.20, 0.34);
    float dayF = dayFactor();

    // Twilight warmth must be a TENT (peaks at sunset ~12500 / sunrise ~23200,
    // zero at midday). The old reversed smoothstep(23500,22500,t) returned 1.0
    // for the ENTIRE day (t<22500), which warmed the daytime ambient into a
    // constant pink wash on white surfaces — THE bug. These tents are 0 at noon.
    float t = float(worldTime);
    float sunset  = smoothstep(11000.0, 12500.0, t) * (1.0 - smoothstep(12500.0, 13800.0, t));
    float sunrise = smoothstep(22200.0, 23200.0, t) * (1.0 - smoothstep(23200.0, 24000.0, t));
    float dusk = max(sunset, sunrise);

    vec3 amb = mix(nightAmb, dayAmb, dayF);
    amb = mix(amb, vec3(0.55, 0.42, 0.40), dusk * 0.30);   // warm only at dawn/dusk
    amb = mix(amb, vec3(0.30, 0.32, 0.36), rainStrength * 0.5);
    return amb;
}

// Warm block-light (torch) color.
vec3 getBlockLightColor() {
    return vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B);
}

// ============================================================================
//  WORLD-SPACE LIGHT DIRECTION
//
//  shadowLightPosition points (in view space) toward whichever celestial body
//  is currently the shadow caster (sun by day, moon by night). Rotating it by
//  gbufferModelViewInverse yields the true world-space direction TO the light.
// ============================================================================

vec3 getWorldLightDir() {
    vec3 v = shadowLightPosition;
    if (length(v) < 0.01) v = lightingIsDay() ? sunPosition : moonPosition;
    if (length(v) < 0.01) v = vec3(0.0, 1.0, 0.3);
    return normalize(mat3(gbufferModelViewInverse) * normalize(v));
}

// ============================================================================
//  COOK-TORRANCE (GGX) BRDF
// ============================================================================

float D_GGX(float NdotH, float rough) {
    float a  = rough * rough;
    float a2 = a * a;
    float d  = (NdotH * NdotH) * (a2 - 1.0) + 1.0;
    return a2 / max(PI * d * d, 1e-5);
}

float G_SchlickGGX(float NdotX, float rough) {
    float r = rough + 1.0;
    float k = (r * r) / 8.0;
    return NdotX / (NdotX * (1.0 - k) + k);
}

float G_Smith(float NdotV, float NdotL, float rough) {
    return G_SchlickGGX(NdotV, rough) * G_SchlickGGX(NdotL, rough);
}

vec3 F_Schlick(float cosT, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosT, 0.0, 1.0), 5.0);
}

// Full Cook-Torrance for one light. N,V,L are world-space unit vectors.
// radiance already includes light color * intensity * shadow * NdotL gating.
vec3 cookTorrance(vec3 N, vec3 V, vec3 L, vec3 albedo,
                  float metallic, float roughness, vec3 radiance) {
    float NdotL = max(dot(N, L), 0.0);
    if (NdotL <= 0.0) return vec3(0.0);

    vec3  H     = normalize(V + L);
    float NdotV = max(dot(N, V), 1e-4);
    float NdotH = max(dot(N, H), 0.0);
    float VdotH = max(dot(V, H), 0.0);

    vec3  F0 = mix(vec3(0.04), albedo, metallic);

    float D = D_GGX(NdotH, roughness);
    float G = G_Smith(NdotV, NdotL, roughness);
    vec3  F = F_Schlick(VdotH, F0);

    vec3 spec = (D * G * F) / (4.0 * NdotV * NdotL + 1e-4);

    vec3 kd      = (vec3(1.0) - F) * (1.0 - metallic);
    vec3 diffuse = kd * albedo / PI;

    return (diffuse + spec) * radiance * NdotL;
}

// ============================================================================
//  SHADOWS (with colored transmission)
//
//  Returns an RGB light multiplier in [0,1]: white = fully lit, black = full
//  shadow, tinted = light passing through a translucent (stained glass/water)
//  occluder via shadowcolor0.
// ============================================================================

vec3 getShadowColor(vec3 playerPos, vec3 N, float NdotL) {
    // Grazing surfaces receive almost no direct sun (sun ∝ NdotL) yet are the
    // single worst source of self-shadow acne. Treat near-grazing faces as
    // shadowed before we ever sample — removes the dashed acne with negligible
    // light loss and no hard terminator (cookTorrance already fades by NdotL).
    if (NdotL <= 0.07) return vec3(0.0);

    float dist = length(playerPos);

    // Normal-offset bias: push the sample off the surface, scaling with distance
    // (distant texels cover more world space) and a little with grazing angle.
    float grazing = 1.0 - NdotL;
    float nOffset = (0.05 + dist * 0.0035) * (1.0 + grazing * 1.5);
    vec3  wp = playerPos + N * nOffset;

    vec3 sc = (shadowProjection * shadowModelView * vec4(wp, 1.0)).xyz;

    float distortF = length(sc.xy) + SHADOW_DISTORT_FACTOR;
    vec3 sd = distort(sc) * 0.5 + 0.5;

    if (sd.x < 0.0 || sd.x > 1.0 || sd.y < 0.0 || sd.y > 1.0 || sd.z > 1.0)
        return vec3(1.0);

    // Depth bias with a real FLOOR (fixes near-field acne) plus a grazing term,
    // scaled by the distortion so distant texels stay clean.
    float bias = (0.0008 + grazing * 0.0025) * (distortF * distortF) / SHADOW_DISTORT_FACTOR;
    bias = clamp(bias, 0.0006, 0.0060);
    float recZ = sd.z - bias;

    // DISTANCE-FEATHERED PCF radius: shadows soften the farther they are.
    float texel  = 1.0 / float(shadowMapResolution);
    float radius = (1.0 + dist * 0.20) * texel;
    radius = clamp(radius, texel, 0.0040);

    int   samples = int(SHADOW_SAMPLES);
    float invN    = 1.0 / float(samples);
    float opaque  = 0.0;
    vec3  colored = vec3(0.0);

    for (int i = 0; i < samples; i++) {
        vec2 off = poisson32(i) * radius;
        opaque += step(recZ, texture2D(shadowtex1, sd.xy + off).r);
        float a = step(recZ, texture2D(shadowtex0, sd.xy + off).r);
        // Light that passes the opaque test but is blocked by a translucent
        // occluder is tinted by shadowcolor0 (stained glass / water).
        colored += mix(texture2D(shadowcolor0, sd.xy + off).rgb, vec3(1.0), a);
    }

    opaque  *= invN;
    colored *= invN;

    return vec3(opaque) * colored;
}

// ============================================================================
//  BLOCK (POINT) LIGHT  — stable, derivative-free
//
//  The old version reconstructed a light direction from the SCREEN-SPACE
//  gradient (dFdx/dFdy) of the block-light field. On flat walls that gradient is
//  quantized/noisy and produced the dashed "siyah çizgi" speckle all over lit
//  surfaces. Real per-emitter direction needs voxel data we don't have, so we
//  model block light as a soft omnidirectional area fill shaped only by the
//  (stable) geometric normal. No screen-space derivatives = no speckle.
// ============================================================================

vec3 blockLightBRDF(vec3 N, vec3 V, vec3 worldPos, float blockLight,
                    vec3 albedo, float metallic, float roughness) {
    float bl = clamp(blockLight, 0.0, 1.0);
    if (bl <= 0.001) return vec3(0.0);

    // STEEP falloff so the (already lower) light level behind a block reads as a
    // real shadow instead of a flat wash. Minecraft's flood-fill light is blocked
    // by solid blocks, so a steeper curve turns that data into visible contrast.
    float att = bl * bl;

    // Screen-space occlusion (SSAO) applied to block light too: this is what
    // darkens the ground directly behind a block placed in front of a torch.
    att *= mix(1.0, gAO, 0.8);

    vec3 radiance = getBlockLightColor() * BLOCKLIGHT_STRENGTH * att;

    // Soft top-weighted shaping from the geometric normal only (stable). Faces
    // pointing up catch a touch more, but every face still receives fill so the
    // light reads as area/omni, never directional speckle.
    float shape = 0.70 + 0.30 * (dot(N, vec3(0.0, 1.0, 0.0)) * 0.5 + 0.5);

    vec3 diffuse = albedo * radiance * shape * (1.0 - metallic);

    // A small, stable specular highlight using a fixed "from slightly above"
    // light vector so smooth/metal surfaces still glint under torches.
    vec3  L     = normalize(N + vec3(0.0, 0.8, 0.0));
    vec3  spec  = cookTorrance(N, V, L, albedo, metallic, roughness, radiance) * 0.5;

    return diffuse + spec;
}

#ifdef VOXEL_LIGHTING
// Shade with the voxel light field: `lightCol` is the incoming colored block
// light at this point (already distance-attenuated AND hard-occluded by the
// voxel propagation), so behind a solid block it is simply zero -> real shadow.
vec3 voxelBlockTerm(vec3 N, vec3 V, vec3 albedo, float metallic, float roughness, vec3 lightCol) {
    vec3 radiance = lightCol * VOXEL_BLOCKLIGHT_STRENGTH;
    float shape = 0.70 + 0.30 * (dot(N, vec3(0.0, 1.0, 0.0)) * 0.5 + 0.5);
    vec3 diffuse = albedo * radiance * shape * (1.0 - metallic);
    vec3 L    = normalize(N + vec3(0.0, 0.6, 0.0));
    vec3 spec = cookTorrance(N, V, L, albedo, metallic, roughness, radiance) * 0.4;
    return diffuse + spec;
}
#endif

// ============================================================================
//  MASTER LIGHTING
//
//  Inputs are all world-space. playerPos is the eye-relative position
//  (worldPos - cameraPosition). Returns the fully lit (pre-fog) color.
// ============================================================================

// blockLight/skyLight arrive as Minecraft's raw lightmap TEXTURE coordinate
// (gl_MultiTexCoord1 through gl_TextureMatrix[1]), which samples a 16x16
// lightmap texture with a half-texel border: light level 0 lands at
// texcoord 1/32 = 0.03125, level 15 at 30/32+1/32 = 0.96875 -- NOT 0 and 1.
// Every gbuffer writer (terrain/entities/block/textured/hand/water) passes
// this raw coordinate straight through, so "zero light" was actually read as
// ~0.03, which smoothstep(0.0, 0.35, skyLight) let past its gate at ~9%
// strength. That is the underground "light leak": full-dark caves still
// picked up a sliver of the current sun/moon-tinted direct light and sky
// ambient, which is exactly why deep caves tracked the day/night cycle and
// entities standing on unlit ground still read as lit. Undo the texel
// mapping here so 0 truly means 0 for every consumer.
float unpackLightmap(float raw) {
    return clamp((raw - (1.0 / 32.0)) / (30.0 / 32.0), 0.0, 1.0);
}

vec3 computeSceneLighting(vec3 albedo, vec3 N, vec3 playerPos,
                          float blockLight, float skyLight,
                          float metallic, float roughness, float emissive) {
    vec3 worldPos = playerPos + cameraPosition;
    vec3 V = normalize(-playerPos);             // toward camera (camera at origin of player space)

    roughness = clamp(roughness, 0.04, 1.0);
    skyLight   = unpackLightmap(skyLight);
    blockLight = unpackLightmap(blockLight);

    // ---- Sun / Moon directional light -------------------------------------
    vec3 L = getWorldLightDir();
    float NdotL = max(dot(N, L), 0.0);
    float intensity = lightingIsDay() ? SUN_ILLUMINANCE : MOON_ILLUMINANCE;
    intensity *= (1.0 - rainStrength * 0.6);

    vec3 shadow = gForceNoShadow ? vec3(1.0) : getShadowColor(playerPos, N, NdotL);
    // CUBIC sky gate, not linear/smoothstep-to-0.35: a shaft with partial sky
    // connection (skyLight ~0.3-0.6 -- e.g. a mineshaft a few blocks from an
    // opening) used to reach near-full sun/moon strength past just 35% skyLight.
    // That is why tunnels near an opening still tracked the day/night cycle
    // strongly, and why entities there flickered bright/dark as they turned --
    // a directional light (NdotL-gated) at meaningful strength lights whichever
    // face happens to point toward the sun and leaves the rest dark, which
    // reads as "patchy"/inconsistent on a multi-faced animated model. Now only
    // genuinely open sky (skyLight -> 1.0) gets full strength; a partial shaft
    // gets a small fraction of it.
    float skyGate = pow(clamp(skyLight, 0.0, 1.0), 3.0);
    vec3 sunRadiance = getSunlightColor() * intensity * shadow * skyGate;

    vec3 direct = cookTorrance(N, V, L, albedo, metallic, roughness, sunRadiance);

    // ---- Block light: voxel colored (occluded) if available, else omni -----
    vec3 block;
#ifdef VOXEL_LIGHTING
    if (gUseVoxelLight)
        block = voxelBlockTerm(N, V, albedo, metallic, roughness, gVoxelBlockLight);
    else
#endif
        block = blockLightBRDF(N, V, worldPos, blockLight, albedo, metallic, roughness);

    // ---- Hemispheric sky ambient ------------------------------------------
    //  Sky ambient scales with skyLight (so it vanishes underground) and uses
    //  the day/night sky color. The constant fill is kept SEPARATE with a fixed,
    //  time-independent color so caves are NOT brighter by day / black at night
    //  (they have no sky access — only this fill + block light should reach them).
    float hemi = dot(N, vec3(0.0, 1.0, 0.0)) * 0.5 + 0.5;
    // Use the same cubic skyGate as the direct sun term (not raw skyLight) so
    // the day/night-tinted sky color also fades out steeply in a partially-lit
    // shaft, instead of washing the whole tunnel in the current time-of-day
    // color. The neutral MIN_AMBIENT fill below is untouched (still scales with
    // nothing but a fixed color), so caves stay lit but colorless.
    vec3 ambient = albedo * getSkyAmbientColor() * (hemi * SKY_AMBIENT_STRENGTH * skyGate)
                 + albedo * vec3(0.40, 0.42, 0.48) * MIN_AMBIENT;
    // metals have no diffuse ambient
    ambient *= (1.0 - metallic * 0.85);
    // screen-space ambient occlusion (1.0 in forward passes)
    ambient *= gAO;

    // ---- Emissive (albedo-multiplied so texture detail is preserved) -------
    vec3 emission = albedo * emissive * EMISSION_STRENGTH;

    vec3 result = direct + block + ambient + emission;

    // ---- Underwater caustics (only when submerged) ------------------------
    //  Sunlight focused by the surface into a moving network on lit geometry.
    //  World-stable (worldPos), sun-colored, masked by skyLight (needs open
    //  water above) and biased to up-facing surfaces (sea floor catches most).
#ifdef CAUSTICS
    if (isEyeInWater == 1 && skyLight > 0.02) {
        float ca   = caustics(worldPos, frameTimeCounter);
        float face = clamp(N.y, 0.0, 1.0);                      // ONLY up-facing seabed, no wall streaks
        float dayC = mix(0.15, 1.0, dayFactor());               // smooth day/night fade
        // Caustics belong on the SEABED (up-facing). Down-facing surfaces — walls
        // and especially the underside of the surface (the "ceiling") — get almost
        // none, so the water surface stops looking like a field of dots.
        vec3  caus = getSunlightColor() * ca * skyLight * (0.05 + 0.95 * face)
                   * CAUSTIC_STRENGTH * dayC;
        result += albedo * caus;                                // adds as extra light on the surface
    }
#endif

    return result;
}

// ============================================================================
//  VOLUMETRIC LIGHT (god rays)
//
//  Ray-march from the camera to the fragment through the shadow map, counting
//  how much of the path is sunlit, and add that in-scatter tinted by the sun
//  color. World-space, shadow-map driven (no fake camera light). jitter in
//  [0,1) de-bands the march.
// ============================================================================

vec3 volumetricLight(vec3 playerPos, float jitter) {
#ifdef VOLUMETRIC_LIGHT
    float rayLen  = min(length(playerPos), 48.0);   // cap so sky pixels don't march to infinity
    if (rayLen < 0.5) return vec3(0.0);

    vec3  dir     = normalize(playerPos);
    int   steps   = int(VL_SAMPLES);
    float stepLen = rayLen / float(steps);
    vec3  rayStep = dir * stepLen;
    vec3  pos     = rayStep * jitter;

    float accum = 0.0;
    for (int i = 0; i < steps; i++) {
        vec3 sc = (shadowProjection * shadowModelView * vec4(pos, 1.0)).xyz;
        vec3 sd = distort(sc) * 0.5 + 0.5;
        if (sd.x > 0.0 && sd.x < 1.0 && sd.y > 0.0 && sd.y < 1.0)
            accum += step(sd.z - 0.0008, texture2D(shadowtex1, sd.xy).r);
        else
            accum += 1.0;   // beyond the shadow map = treat as lit
        pos += rayStep;
    }
    accum /= float(steps);

    // Forward-scatter phase: concentrate the in-scatter toward the sun so it
    // reads as shafts/god rays. Exponent lowered (9 -> 5) so the shafts stay
    // visible across a WIDER angle instead of only when staring straight at the
    // sun, and the floor raised (0.06 -> 0.20) so god rays still read even when
    // you're looking away from / far to the side of the light shaft.
    float phase = pow(max(dot(dir, getWorldLightDir()), 0.0), 5.0);
    float w = mix(0.20, 1.0, phase);

    // Scale by how much AIR the ray crossed so near surfaces don't wash out, but
    // reach full strength SOONER (÷28, gentler curve) so the rays are visible at
    // moderate distance too, not only across a huge sky gap.
    float distFactor = clamp(rayLen / 28.0, 0.0, 1.0);
    distFactor = pow(distFactor, 1.3);

    float dayF = mix(0.25, 1.0, dayFactor());

    // Underwater god rays: separately tunable, water-tinted, stronger forward
    // scatter so light shafts read clearly through the murk.
    if (isEyeInWater == 1) {
        vec3 uwColor = mix(getSunlightColor(), vec3(0.35, 0.72, 0.90), 0.6);
        float uwPhase = mix(0.04, 1.0, pow(max(dot(dir, getWorldLightDir()), 0.0), 6.0));
        return uwColor * accum * uwPhase * distFactor * VL_UNDERWATER_STRENGTH * dayF;
    }

    return getSunlightColor() * accum * w * distFactor * VL_STRENGTH * dayF * (1.0 - rainStrength * 0.4);
#else
    return vec3(0.0);
#endif
}

// ============================================================================
//  ATMOSPHERIC FOG (day/night/rain) + underwater fog
// ============================================================================

vec3 applySceneFog(vec3 color, vec3 playerPos, float skyLight) {
    float dist = length(playerPos);

    if (isEyeInWater == 1) {
        // Cinematic underwater: per-channel Beer-Lambert absorption (red dies
        // near, blue-green lingers) fading into biome-tinted murk with distance.
        // Distance is first run through the perceptual DEPTH COMPRESSION so the
        // submerged world reads as pulled-in / closer, not a clear far view.
        float dayF   = dayFactor();
        float uwDist = underwaterCompressDist(dist, far);
        return underwaterColorize(color, uwDist, fogColor, dayF);
    }

    // TRUE AERIAL PERSPECTIVE: distant geometry fades toward the actual sky
    // color in its own view direction (with distance desaturation + blue-shift),
    // instead of a single flat fog tint. World-space sun direction so dawn/dusk
    // warmth and the day/night transition come for free from the sky model.
    vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    return applyAerialPerspective(color, playerPos, sunDir, rainStrength, far);
}

#endif // LIGHTING_GLSL
