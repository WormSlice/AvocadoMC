// Water constants
//  .a is the BASE opacity looking straight down. Lower = clearer water that shows
//  the bottom (sand/gravel) through it, which is what stops a shallow pool reading
//  as a flat blue lid. Grazing angles still ramp toward opaque+reflective via the
//  Fresnel term in gbuffers_water, so distant water stays a mirror.
vec4 WATER_COLOR = vec4(vec3(0.12, 0.30, 0.44), 0.50);
vec3 WATER_NORMAL = vec3(0.0, 1.0, 0.0);
float WATER_WAVE_SPEED = 0.6;
float WATER_WAVE_SCALE = 0.22;
float WATER_FRESNEL_POWER = 5.0;

#define WATER_NORMAL_STRENGTH 0.45  // [0.1 0.3 0.45 0.6 0.9 1.1 1.3 1.5 1.8 2.2 2.8] wave bumpiness

#ifndef FRAMETIME_DECLARED
#define FRAMETIME_DECLARED
uniform float frameTimeCounter;
#endif

// One directional wave's contribution to the height-field gradient.
//  dir   : unit travel direction (xz)
//  freq  : spatial frequency (1/blocks)
//  speed : temporal speed
//  amp   : amplitude
vec2 waveGrad(vec2 p, vec2 dir, float freq, float speed, float amp, float t) {
	float ph = dot(p, dir) * freq + t * speed;
	return dir * (cos(ph) * freq * amp);
}

// Anti-tiling water normal: an automatic height-field built from many waves
// travelling in clearly different directions at INCOMMENSURATE frequencies, then
// differentiated into a per-pixel NORMAL MAP (like an RTX detail normal). Because
// no two waves share a direction or a rational frequency ratio, the surface never
// shows diagonal "tekrarlı" streaks. A domain-warp on the fine octaves bends the
// small ripples over the big swells, so you get crisp, organic micro-detail that
// catches the sky reflection instead of one flat sheet.
vec3 getWaterNormal(vec3 worldPos) {
	float t = frameTimeCounter * WATER_WAVE_SPEED;
	vec2  p = worldPos.xz;

	// ---- Base swell + chop: the large, slow height structure ------------------
	vec2 g = vec2(0.0);
	//                   direction          freq    speed  amp
	g += waveGrad(p, vec2( 0.94,  0.34), 0.090, 0.55, 0.060, t); // broad swell
	g += waveGrad(p, vec2( 0.26,  0.97), 0.151, 0.80, 0.040, t);
	g += waveGrad(p, vec2(-0.64,  0.77), 0.237, 1.10, 0.026, t);
	g += waveGrad(p, vec2(-0.97, -0.22), 0.383, 1.45, 0.016, t);
	g += waveGrad(p, vec2( 0.34, -0.94), 0.619, 1.90, 0.010, t); // chop

	// ---- Domain warp: push the fine ripples around by the coarse height so the
	//      detail layer flows over the swells instead of sitting on a flat grid.
	vec2 warp = g * 1.5;
	vec2 pf   = p + warp;

	// ---- Fine ripple octaves: the crisp RTX-style micro normal detail ---------
	//      Higher frequency, lower amplitude, faster — these are what make the
	//      surface sparkle when it reflects the sky.
	g += waveGrad(pf, vec2( 0.80,  0.60), 1.013, 2.60, 0.0060, t);
	g += waveGrad(pf, vec2(-0.42,  0.91), 1.627, 3.10, 0.0040, t);
	g += waveGrad(pf, vec2( 0.99, -0.14), 2.633, 3.70, 0.0026, t);
	g += waveGrad(pf, vec2(-0.71, -0.70), 4.259, 4.40, 0.0017, t);
	g += waveGrad(pf, vec2( 0.15,  0.99), 6.887, 5.20, 0.0011, t); // finest chop

	g *= WATER_NORMAL_STRENGTH * 6.0;

	return normalize(vec3(-g.x, 1.0, -g.y));
}

float getWaterFresnel(vec3 viewDir, vec3 normal) {
	float cosTheta = clamp(dot(-viewDir, normal), 0.0, 1.0);
	float fresnel = pow(1.0 - cosTheta, WATER_FRESNEL_POWER);
	return clamp(fresnel + 0.02, 0.0, 1.0); // small base reflectance at grazing-0
}