// ============================================================================
//  lib/underwater.glsl   (Stage 5 — cinematic underwater)
//
//  Self-contained, pure-function underwater toolkit. EVERY effect here is only
//  ever called behind an `isEyeInWater == 1` guard by the host pass, so normal
//  above-water performance is untouched. No uniform declarations (callers pass
//  what's needed), #version 120 safe (constant loop bounds, no derivatives,
//  world-space inputs).
//
//  Pieces:
//    underwaterColorize() : Beer-Lambert per-channel absorption + murk fog
//    caustics()           : world-stable procedural caustic network
//    marineSnow()         : drifting suspended particles (screen-space)
//    uwWobble()           : multi-frequency screen distortion
//    uwGrade()            : blue-green white balance + contrast + vignette
//    snellGlow()          : cheap "bright surface above" cue (optional)
// ============================================================================

#ifndef UNDERWATER_GLSL
#define UNDERWATER_GLSL

#ifndef PI
#define PI 3.14159265359
#endif

// ---- Config (sliders/toggles; guarded so callers can override) -------------
#ifndef FOG_DENSITY_UNDERWATER
#define FOG_DENSITY_UNDERWATER 0.60  // [0.50 0.60 0.75 1.00 1.30 1.60 2.00] murk / absorption thickness
#endif
// Per-channel extinction ratio (clear water: red dies fast, blue lingers).
#define UW_ABSORB_R 0.46
#define UW_ABSORB_G 0.08
#define UW_ABSORB_B 0.035

#define CAUSTICS                     // toggle: projected caustic light
#ifndef CAUSTIC_STRENGTH
#define CAUSTIC_STRENGTH 1.80   // [0.00 0.30 0.60 0.90 1.30 1.80] caustic brightness
#endif
#ifndef CAUSTIC_SCALE
#define CAUSTIC_SCALE 0.50      // [0.15 0.25 0.35 0.50 0.70] pattern frequency
#endif
#ifndef CAUSTIC_SPEED
#define CAUSTIC_SPEED 0.30      // [0.00 0.30 0.60 1.00 1.50] animation speed
#endif

#define MARINE_SNOW                  // toggle: suspended particles
#ifndef MARINE_SNOW_AMOUNT
#define MARINE_SNOW_AMOUNT 0.00 // [0.00 0.25 0.50 0.80 1.20] particle density
#endif

#ifndef VL_UNDERWATER_STRENGTH
#define VL_UNDERWATER_STRENGTH 2.20  // [0.00 0.40 0.70 0.90 1.20 1.60 2.20] underwater god-ray strength
#endif

#ifndef UW_WOBBLE
#define UW_WOBBLE 0.50          // [0.00 0.50 1.00 1.50 2.50] screen wobble
#endif
#ifndef UW_ABERRATION
#define UW_ABERRATION 2.50      // [0.00 0.50 1.00 1.50 2.50] edge chromatic aberration
#endif
#ifndef UW_VIGNETTE
#define UW_VIGNETTE 0.70        // [0.00 0.30 0.50 0.70 1.00] corner darkening
#endif
#ifndef UW_TINT
#define UW_TINT 1.00            // [0.00 0.25 0.50 0.75 1.00] blue-green grade
#endif
#define SNELL_WINDOW                 // toggle: bright-surface-above cue

#ifndef UW_DEPTH_COMPRESS
#define UW_DEPTH_COMPRESS 0.85  // [0.50 0.60 0.65 0.75 0.85 1.00] <1 = world feels pulled closer
#endif

// ---- small hashes ----------------------------------------------------------
vec2 uwHash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453);
}

// ============================================================================
//  1. DEPTH ABSORPTION (Beer-Lambert) + MURK FOG
//     color   : lit scene radiance at the fragment
//     dist    : eye->fragment distance through water (blocks)
//     biomeFog: OptiFine's underwater fogColor (biome water tint)
//     dayF    : 1 day .. 0 night
// ============================================================================
vec3 underwaterColorize(vec3 color, float dist, vec3 biomeFog, float dayF) {
    // ---- 1. BEER-LAMBERT ABSORPTION (spectral) --------------------------------
    // Red is absorbed within a few blocks, green mid, blue lingers -> the scene
    // shifts blue-green with distance. Per-channel transmittance of the SCENE.
    vec3 sigma = vec3(UW_ABSORB_R, UW_ABSORB_G, UW_ABSORB_B) * FOG_DENSITY_UNDERWATER;
    vec3 trans = exp(-sigma * dist);

    // ---- 2. IN-SCATTER / MURK COLOUR (the depth cue) --------------------------
    // Real clear water is a DESATURATED teal near the surface, not a saturated
    // cobalt wall. Bright-ish teal near, deepening to a muted blue far. Kept low-
    // saturation so the scene stays readable and doesn't drown in blue.
    vec3 shallow = vec3(0.26, 0.42, 0.38);           // desaturated teal-green, not cobalt
    vec3 deep    = vec3(0.07, 0.17, 0.19);           // muted deep teal, NOT navy blue
    float deepF  = 1.0 - exp(-dist * 0.030);         // slower slide to deep = clearer mid-range
    vec3 wc = mix(shallow, deep, deepF);
    wc = mix(wc, biomeFog, 0.25);                    // mostly our tuned tint
    wc *= mix(0.22, 1.0, dayF);                      // darker at night

    // ---- 3. SCATTERING (haze build-up) ----------------------------------------
    // How much murk has replaced the scene by this distance. Much gentler now so
    // you can actually SEE across the water; the far world still fades out (loss of
    // contrast = the "closer" cue) but only well into the distance.
    float haze = 1.0 - exp(-dist * 0.045 * FOG_DENSITY_UNDERWATER);

    // Absorbed scene radiance + in-scattered murk. max() of the two fades keeps
    // strongly-absorbed (red) channels from going pure black before the murk fills
    // in, so deep water reads as luminous blue, not a dead flat colour.
    vec3 scene = color * trans;
    return mix(scene, wc, haze);
}

// ============================================================================
//  1b. DEPTH COMPRESSION / PERCEPTUAL SCALING
//     Underwater the eye badly misjudges distance — the world feels pulled in and
//     "closer / denser" than it really is. We fake it by remapping the through-
//     water eye distance with a pow < 1: near-to-mid ranges are pushed outward so
//     the fog + Beer-Lambert absorption above build up SOONER, which reads as a
//     compressed, enclosing, closer world. This is the piece most underwater
//     shaders skip. Feed the result into underwaterColorize instead of raw dist.
// ============================================================================
float underwaterCompressDist(float dist, float farPlane) {
    // Reference a FIXED ~30-block underwater sight range, NOT the render distance:
    // normalising by the (huge) far plane made even near blocks read as tens of
    // blocks away and fogged the whole scene to flat blue. With a fixed range the
    // pow<1 gently exaggerates mid distances (world feels pulled-in) while near
    // objects stay clear and readable.
    const float REF = 30.0;
    float d = clamp(dist / REF, 0.0, 4.0);
    d = pow(d, UW_DEPTH_COMPRESS);                   // <1 => nearer/denser feel
    return d * REF;
}

// ============================================================================
//  2. CAUSTICS — world-stable procedural network (cellular F1, two layers).
//     Returns 0..1 caustic intensity at a world position.
// ============================================================================
// Voronoi F2-F1 EDGE network: tracks the two nearest feature points and returns
// the gap between them, which goes to ~0 exactly on the border BETWEEN cells.
// Thresholding that gap gives thin bright lines along the cell walls — the real
// caustic "cracked glass / net" look (like the reference texture) instead of a
// field of blobs at the cell centres.
// Returns .x = edge-network line intensity, .y = distance to nearest point (F1).
// The feature points ORBIT with time so the whole web morphs/breathes instead of
// rigidly sliding — that living, refocusing motion is what sells caustics as real
// bent light rather than a pasted texture.
vec2 causticNet(vec2 uv, float t) {
    vec2 g = floor(uv);
    vec2 f = fract(uv);
    float f1 = 8.0, f2 = 8.0;                         // nearest, second-nearest (squared)
    for (int y = -1; y <= 1; y++)
    for (int x = -1; x <= 1; x++) {
        vec2 o  = vec2(float(x), float(y));
        vec2 h  = uwHash2(g + o);
        vec2 pt = 0.5 + 0.42 * sin(t + h * 6.2831853); // animated orbiting point
        vec2 r  = o + pt - f;
        float d = dot(r, r);
        if (d < f1) { f2 = f1; f1 = d; }
        else if (d < f2) { f2 = d; }
    }
    float edge = sqrt(f2) - sqrt(f1);                // 0 on the wall between two cells
    float line = 1.0 - smoothstep(0.0, 0.16, edge);  // THIN bright ridge lines
    return vec2(line, sqrt(f1));
}

float caustics(vec3 worldPos, float time) {
    vec2 uv = worldPos.xz * CAUSTIC_SCALE * 1.7;     // *1.7 = tighter spacing between lines
    float t = time * CAUSTIC_SPEED;

    // DOMAIN WARP: bend the straight Voronoi cell walls into flowing, curved
    // caustic filaments (straight/evenly-spaced lines are the dead giveaway of a
    // fake procedural net). Two octaves of sine flow, animated.
    uv += 0.45 * vec2(sin(uv.y * 1.7 + t * 1.3), cos(uv.x * 1.6 - t * 1.1));
    uv += 0.22 * vec2(sin(uv.y * 3.9 - t * 1.7), cos(uv.x * 4.1 + t * 1.5));

    // Two morphing webs at different scales/phases -> organic, non-tiling network.
    vec2 a = causticNet(uv,               t);
    vec2 b = causticNet(uv * 1.37 + 5.0,  t * 1.3 + 2.0);

    float web  = max(a.x, b.x * 0.75);               // union of the two line webs
    // FOCAL CORES: where BOTH webs' lines coincide, light piles up into a bright
    // sparkle (like the hot focus points of real caustics). Squared for a sharp,
    // 3D-looking pop rather than a flat wash.
    float core = pow(a.x * b.x, 1.5);

    // LARGE-SCALE FOCUS DRIFT: slow low-frequency modulation so whole patches
    // brighten and dim as the "lens" of the surface wanders — kills the uniform,
    // flat, everywhere-the-same-brightness look.
    float drift = 0.55 + 0.45 * sin(uv.x * 0.35 + t * 1.1)
                              * sin(uv.y * 0.29 - t * 0.8);

    float c = (web * web + core * 2.0) * drift;
    return c;
}

// ============================================================================
//  3. MARINE SNOW — drifting suspended particles (screen-space).
//     uv     : screen uv ; aspect = viewWidth/viewHeight ; time
//     Returns an additive luminance (small).
// ============================================================================
float marineSnow(vec2 uv, float aspect, float time) {
    float s = 0.0;
    for (int k = 0; k < 2; k++) {
        float sc = 16.0 + float(k) * 26.0;
        vec2 p = vec2(uv.x * aspect, uv.y) * sc;
        p.y += time * (0.10 + 0.05 * float(k));      // slow downward drift
        p.x += sin(time * 0.3 + float(k) * 2.0) * 0.5;
        vec2 g = floor(p);
        vec2 f = fract(p);
        vec2 rnd = uwHash2(g + float(k) * 17.0);
        float d = length(f - rnd);
        float twinkle = 0.6 + 0.4 * sin(time * 2.0 + rnd.x * 30.0);
        s += smoothstep(0.10, 0.0, d) * twinkle;
    }
    return s * MARINE_SNOW_AMOUNT * 0.5;
}

// ============================================================================
//  4. SCREEN WOBBLE — multi-frequency, more natural than a single sine.
// ============================================================================
vec2 uwWobble(vec2 uv, float time) {
    vec2 w;
    w.x = sin(uv.y * 38.0 + time * 2.2) * 0.0016
        + sin(uv.y * 14.0 - time * 1.3) * 0.0024;
    w.y = cos(uv.x * 32.0 + time * 1.8) * 0.0016
        + cos(uv.x * 11.0 - time * 1.0) * 0.0024;
    return w * UW_WOBBLE;
}

// ============================================================================
//  5. UNDERWATER GRADE — blue-green white balance + reduced contrast + vignette.
//     Applied in display-referred space (after tonemap/grade).
// ============================================================================
vec3 uwGrade(vec3 col, vec2 uv) {
    // Cool blue-green white balance.
    vec3 balance = vec3(0.82, 1.00, 1.06);
    col = mix(col, col * balance, UW_TINT);

    // Soften contrast a touch (water scatters / hazes).
    float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
    col = mix(col, vec3(luma), 0.10 * UW_TINT);
    col = (col - 0.5) * 0.92 + 0.5;

    // Vignette.
    vec2 d = uv - 0.5;
    float vig = 1.0 - dot(d, d) * (1.6 * UW_VIGNETTE);
    col *= clamp(vig, 0.0, 1.0);

    return max(col, 0.0);
}

// ============================================================================
//  6. SNELL WINDOW (cheap approximation) — the world above water compresses into
//     a bright disk overhead. Without a per-pixel view ray we approximate it as
//     a soft brightening toward the top-centre of the screen. Subtle by design.
// ============================================================================
vec3 snellGlow(vec3 col, vec2 uv) {
#ifdef SNELL_WINDOW
    float up   = smoothstep(0.45, 1.0, uv.y);            // upper screen
    vec2  d    = (uv - vec2(0.5, 0.85));
    float disk = 1.0 - smoothstep(0.18, 0.55, length(d));
    col += vec3(0.10, 0.16, 0.20) * disk * up * 0.6;
#endif
    return col;
}

#endif // UNDERWATER_GLSL
