uniform float near;
uniform float far;
uniform int isEyeInWater;

uniform vec3 cameraPosition;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

// Reserved samplers
uniform sampler2D depthtex0;

// Free samplers
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex9;

// Functions
float linearizeDepth(float depth) 
{
    float z = depth * 2.0 - 1.0; // back to NDC 
    return ((2.0 * near * far) / (far + near - z * (far - near))) / far;	
}

float getDepth(vec2 texcoord) {
    return texture2D(depthtex0, texcoord).r;
}

bool isOutOfTexture(vec2 texcoord) {
    return (texcoord.x < 0.0 || texcoord.x > 1.0 || texcoord.y < 0.0 || texcoord.y > 1.0);
}

bool isWater(vec2 uv) {
    // Water mask in colortex5
    return texture2D(colortex5, uv).a > 0.5;
}

vec3 getWorldPosition(vec2 texcoord, float depth) {
    vec3 clipSpace = vec3(texcoord, depth) * 2.0 - 1.0;
    vec4 viewW = gbufferProjectionInverse * vec4(clipSpace, 1.0);
    vec3 viewSpace = viewW.xyz / viewW.w;
    vec4 world = gbufferModelViewInverse * vec4(viewSpace, 1.0);

    return world.xyz;
}

vec3 getUVFromPosition(vec3 position) {
    vec4 projection = gbufferProjection * gbufferModelView * vec4(position, 1.0);
    projection.xyz /= projection.w;
    vec3 clipSpace = projection.xyz * 0.5 + 0.5;

    return clipSpace.xyz;
}

float random01(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

// Stable screen-space reflection: a linear ray march with a growing step and a
// binary-search refinement once the ray crosses the depth buffer. The old
// version reprojected the ray to scene depth every step, which oscillated and
// produced concentric "ring" artifacts on flat water. This does not.
vec2 raytrace(vec3 startPosition, vec3 reflectionDir) {
    float stepLen = 0.45;          // initial march step (player-space units)
    vec3  pos     = startPosition;
    vec3  prevPos = startPosition;

    for (int i = 0; i < 48; i++) {
        prevPos = pos;
        pos    += reflectionDir * stepLen;

        vec3 uv = getUVFromPosition(pos);
        if (isOutOfTexture(uv.xy)) return vec2(-1.0);

        float sceneDepth = getDepth(uv.xy);
        if (sceneDepth >= 1.0) { stepLen *= 1.25; continue; } // sky, keep going

        if (uv.z > sceneDepth) {
            // Crossed a surface — refine the hit point with a binary search.
            vec3 a = prevPos;
            vec3 b = pos;
            for (int j = 0; j < 6; j++) {
                vec3  mid    = (a + b) * 0.5;
                vec3  midUV  = getUVFromPosition(mid);
                float midD   = getDepth(midUV.xy);
                if (midUV.z > midD) b = mid; else a = mid;
            }
            vec3  hitUV = getUVFromPosition(b);
            float hitD  = getDepth(hitUV.xy);
            // Reject if the gap is too large (the surface was occluded, not hit).
            if (hitD < 1.0 && abs(hitUV.z - hitD) < 0.0025 && !isOutOfTexture(hitUV.xy))
                return hitUV.xy;
            return vec2(-1.0);
        }

        stepLen *= 1.25; // accelerate the march with distance
    }

    return vec2(-1.0);
}
