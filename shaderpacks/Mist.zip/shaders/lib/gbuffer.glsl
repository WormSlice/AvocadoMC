// ============================================================================
//  lib/gbuffer.glsl
//  Shared G-buffer layout + material extraction for VENC shaders.
//
//  Layout (all RGBA8 — no shaders.properties format overrides required):
//    colortex0 (gcolor) : rgb = albedo           a = alpha
//    colortex1          : rg  = octahedral world normal
//                         b   = metallic          a = smoothness (1-roughness)
//    colortex2          : r   = block light       g = sky light
//                         b   = emissive          a = deferred-lighting flag (1=lit)
//
//  World position is reconstructed from depthtex0 in the deferred pass, so it
//  is never stored (avoids RGBA8 precision loss).
// ============================================================================

#ifndef GBUFFER_GLSL
#define GBUFFER_GLSL

// ---- Octahedral normal encoding (world space) ------------------------------
vec2 encodeNormalOct(vec3 n) {
    n /= (abs(n.x) + abs(n.y) + abs(n.z) + 1e-5);
    vec2 e = n.xy;
    if (n.z < 0.0) {
        e = (1.0 - abs(e.yx)) * vec2(e.x >= 0.0 ? 1.0 : -1.0,
                                     e.y >= 0.0 ? 1.0 : -1.0);
    }
    return e * 0.5 + 0.5;
}

vec3 decodeNormalOct(vec2 f) {
    f = f * 2.0 - 1.0;
    vec3 n = vec3(f.x, f.y, 1.0 - abs(f.x) - abs(f.y));
    float t = max(-n.z, 0.0);
    n.x += n.x >= 0.0 ? -t : t;
    n.y += n.y >= 0.0 ? -t : t;
    return normalize(n);
}

// ---- Material extraction from the specular texture (LabPBR style) ----------
//  specular.r = perceptual smoothness, specular.g = F0/metalness,
//  specular.a = emission (255 = none in LabPBR; here treated as 0..1 emission).
//  When no resource-pack specular map is present (texel ~ default), we fall
//  back to an albedo-luminance heuristic so vanilla packs still look right.
struct Material {
    float metallic;
    float smoothness;
    float emissive;
};

Material getMaterial(sampler2D specularTex, vec2 uv, vec3 albedo) {
    Material m;
    vec4 s = texture2D(specularTex, uv);

    // A real specular map has signal in rgb; a flat/absent map falls back to a
    // luminance heuristic (matching the original pack's metallic behaviour).
    bool hasSpecMap = max(max(s.r, s.g), s.b) > 0.004;

    if (hasSpecMap) {
        m.smoothness = s.r;
        m.metallic   = s.g;
        // LabPBR: a in [0,254/255] is emission; 1.0 means "no emission".
        m.emissive   = (s.a < 0.996) ? s.a : 0.0;
    } else {
        // Vanilla pack (no specular map): treat as a plain matte dielectric.
        // The old "bright albedo => metallic" heuristic turned sea lanterns,
        // quartz, white concrete etc. into blown-out flat-white pseudo-mirrors.
        m.metallic   = 0.0;
        m.smoothness = 0.08;
        m.emissive   = 0.0;
    }
    return m;
}

#endif // GBUFFER_GLSL
