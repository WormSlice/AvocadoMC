#version 120

attribute vec4 at_tangent;
attribute vec4 mc_Entity;

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldNormal;
varying vec4 worldTangent;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;

void main() {
    // Held-block id (for in-hand glow blocks); guarded to non-negative like the
    // terrain/entity writers so the emissive-id test in the fsh works.
    blockId = mc_Entity.x;
    if (blockId < 0.0) blockId = 0.0;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    // No lightmap remap here — terrain/entities/block/textured all feed raw
    // (gl_TextureMatrix[1] * uv1), so the hand must match or it shades brighter
    // than the world around it.
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    vec3 viewNormal  = normalize(gl_NormalMatrix * gl_Normal);
    vec3 viewTangent = normalize(gl_NormalMatrix * at_tangent.xyz);
    worldNormal  = normalize(mat3(gbufferModelViewInverse) * viewNormal);
    worldTangent = vec4(normalize(mat3(gbufferModelViewInverse) * viewTangent), at_tangent.w);

    // Use the hand geometry exactly as Minecraft positions it. The previous code
    // shoved every vertex by a fixed view-space offset (+vec3(0.10,-0.05,-0.20)),
    // which pushed the arm through itself so its back/underside showed through —
    // that is the "elimin arkası" artifact. No offset now: correct placement.
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    viewPos = vp.xyz;

    worldPos = (gbufferModelViewInverse * vp).xyz + cameraPosition;

    gl_Position = gl_ProjectionMatrix * vp;
}
