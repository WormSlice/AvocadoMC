#version 120

uniform float frameTimeCounter;
uniform vec3  cameraPosition;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 worldPos;

void main() {
    gl_Position = ftransform();
    texcoord    = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor     = gl_Color;
    worldPos    = gl_Vertex.xyz + cameraPosition;
}
