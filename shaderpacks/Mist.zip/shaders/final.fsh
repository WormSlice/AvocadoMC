#version 120
// Final pass: combine bloom, apply exposure + AgX filmic tonemap + color grade,
// then sRGB-encode for the display. Reads HDR colortex0 and bloom colortex3.

uniform sampler2D colortex0;   // HDR scene
uniform sampler2D colortex2;   // g = skyLight of the opaque surface (for night dim gating)
uniform sampler2D colortex3;   // blurred bloom
uniform sampler2D colortex7;   // adapted scene luminance (auto exposure)
uniform sampler2D colortex8;   // first-person hand (HDR), a=1 where the hand is
uniform int   isEyeInWater;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform vec3  sunPosition;
uniform mat4  gbufferModelViewInverse;
varying vec2 texcoord;

#include "/lib/tonemap.glsl"
#include "/lib/underwater.glsl"

#define BLOOM                  // toggle: bloom glow on/off
#define TONEMAP_AGX            // toggle: AgX filmic tonemap (off = Reinhard)
#define AUTO_EXPOSURE          // toggle: eye adaptation (auto exposure)
#define BLOOM_INTENSITY 0.07   // [0.00 0.012 0.022 0.035 0.05 0.07 0.10 0.15 0.25]
#define AUTO_EXP_TARGET 0.26   // [0.10 0.14 0.18 0.20 0.26 0.34 0.45] target middle-grey
#define AUTO_EXP_MIN    0.85   // [0.40 0.55 0.70 0.85 1.00] min exposure clamp
#define AUTO_EXP_MAX    2.20   // [1.20 1.35 1.50 1.80 2.20] max exposure clamp
#define NIGHT_DIM       0.32   // [0.15 0.25 0.32 0.45 0.60 0.80 1.00] how dark night gets (1.0 = no day/night dimming)

void main() {
    vec2 uv = texcoord;

    // Underwater screen wobble: multi-frequency flow (more natural than one sine).
    if (isEyeInWater == 1) {
        uv += uwWobble(texcoord, frameTimeCounter);
        uv = clamp(uv, vec2(0.001), vec2(0.999));
    }

    // Underwater chromatic aberration: split R/B radially toward the edges.
    vec3 hdr;
    if (isEyeInWater == 1) {
        vec2 ca = (uv - 0.5) * (0.0030 * UW_ABERRATION);
        hdr.r = texture2D(colortex0, uv + ca).r;
        hdr.g = texture2D(colortex0, uv).g;
        hdr.b = texture2D(colortex0, uv - ca).b;
    } else {
        hdr = texture2D(colortex0, uv).rgb;
    }

#ifdef BLOOM
    vec3 bloom = texture2D(colortex3, uv).rgb;
    hdr += bloom * BLOOM_INTENSITY;
#endif

    hdr *= EXPOSURE;

    float sceneExp = EXPOSURE;
#ifdef AUTO_EXPOSURE
    float adapted = texture2D(colortex7, texcoord).r;
    float autoExp = clamp(AUTO_EXP_TARGET / max(adapted, 1e-3), AUTO_EXP_MIN, AUTO_EXP_MAX);
    sceneExp *= autoExp;
    hdr *= autoExp;
#endif

    // ---- Genuine day/night brightness (SKY-gated) --------------------------
    //  Auto-exposure fights the natural day->night darkening, so without this
    //  dusk looked as bright as noon. BUT the dimming must only touch surfaces
    //  that actually see the SKY -- a torch-lit interior at night must stay lit.
    //  So we scale the night dim by this pixel's skyLight: skyLight~0 (indoor,
    //  block-lit) -> no dimming; skyLight~1 (open outdoor) -> full night dim.
    //  (colortex2.g is Minecraft's raw lightmap coord -> unpack like lighting.glsl.)
    vec3  sunDirW  = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    float dayness  = smoothstep(-0.06, 0.14, sunDirW.y);   // 0 = night, 1 = day
    float skyRaw   = texture2D(colortex2, texcoord).g;
    float skyLight = clamp((skyRaw - (1.0 / 32.0)) / (30.0 / 32.0), 0.0, 1.0);
    float nightDim = mix(NIGHT_DIM, 1.0, dayness);          // outdoor dim factor
    hdr *= mix(1.0, nightDim, skyLight);                    // only where sky is seen

#ifdef TONEMAP_AGX
    vec3 mapped = agxTonemap(hdr);
#else
    vec3 mapped = reinhardTonemap(hdr);
#endif

    mapped = colorGrade(mapped);

    // ---- Underwater look (display-referred, submerged only) ----------------
    if (isEyeInWater == 1) {
#ifdef MARINE_SNOW
        float aspect = viewWidth / max(viewHeight, 1.0);
        mapped += vec3(0.70, 0.85, 1.00) * marineSnow(uv, aspect, frameTimeCounter);
#endif
        mapped = uwGrade(mapped, uv);      // blue-green balance + soft contrast + vignette
        mapped = snellGlow(mapped, uv);    // bright surface-above cue
    }

    vec3 outc = linearToSRGB(mapped);

    // ---- Composite the first-person HAND on top ----------------------------
    //  The hand was rendered to its own buffer (colortex8), bypassing bloom /
    //  SSGI / volumetric light / fog, so nothing bleeds onto or through it. Here
    //  we give it the SAME exposure + tonemap + grade as the scene (so it matches)
    //  but NO bloom and NO night dim, then lay it over everything. Use the
    //  un-wobbled texcoord so underwater distortion never warps the hand.
    vec4 hand = texture2D(colortex8, texcoord);
    if (hand.a > 0.001) {
        vec3 h = hand.rgb * sceneExp;
#ifdef TONEMAP_AGX
        h = agxTonemap(h);
#else
        h = reinhardTonemap(h);
#endif
        h = colorGrade(h);
        outc = mix(outc, linearToSRGB(h), hand.a);
    }

    gl_FragColor = vec4(outc, 1.0);
}
