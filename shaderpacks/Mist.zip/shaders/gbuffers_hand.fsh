#version 120

// ============================================================================
//  gbuffers_hand.fsh — the held first-person hand / item.
//  The hand is drawn in the FORWARD (post-deferred) phase, so it must be lit
//  here with the SAME lib/lighting.glsl model the deferred pass uses — it can
//  NOT be a plain G-buffer writer (deferred already ran, so a G-buffer write
//  would never get lit and the hand would show as raw full-bright texture).
//  The deferred-lighting flag in colortex2 is cleared so nothing double-lights.
// ============================================================================

#include "/lib/lighting.glsl"
#include "/lib/gbuffer.glsl"

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldNormal;
varying vec4 worldTangent;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;

// Apply a tangent-space normal map onto the world-space geometric normal.
vec3 applyNormalMap(vec3 N, vec4 T, vec2 uv) {
    vec3 sampleN = texture2D(normals, uv).rgb;
    if (length(sampleN - vec3(0.5)) < 0.02) return normalize(N); // no normal map

    vec3 nm;
    nm.xy = sampleN.xy * 2.0 - 1.0;
    nm.y  = -nm.y;   // Minecraft/labPBR use DirectX normals (green channel inverted)
    nm.z  = sqrt(max(1.0 - dot(nm.xy, nm.xy), 0.0));

    vec3 tangent   = normalize(T.xyz);
    vec3 bitangent = normalize(cross(N, tangent) * T.w);
    mat3 tbn = mat3(tangent, bitangent, normalize(N));
    return normalize(tbn * nm);
}

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    vec3 playerPos = worldPos - cameraPosition;
    vec3 N   = applyNormalMap(worldNormal, worldTangent, texcoord);
    Material mat = getMaterial(specular, texcoord, color.rgb);

    // Same block-id self-emission the terrain/entity writers use, so a held glow
    // block (torch, glowstone, etc.) still emits its own color in-hand.
    if (blockId > 10009.5 && blockId < 10010.5) {
        mat.emissive = max(mat.emissive, 0.28);
    } else if (blockId > 10010.5 && blockId < 10011.5) {
        mat.emissive = max(mat.emissive, 0.34);
    }

    gForceNoShadow = true;   // hand is at the camera — don't self-shadow it

    vec3 lit = computeSceneLighting(color.rgb, N, playerPos,
                                    lmcoord.x, lmcoord.y,
                                    mat.metallic, clamp(1.0 - mat.smoothness, 0.04, 1.0),
                                    mat.emissive);
    // No scene fog: the hand is right at the camera, distance fog makes no sense
    // and it was tinting the arm by the sky color.

    // Render the hand to its OWN buffer (colortex8), NOT colortex0. final.fsh
    // composites this on top of the fully post-processed scene, so nothing
    // (bloom, SSGI, volumetric light, aerial fog) can bleed onto or through the
    // hand -- it is a clean top layer. Alpha = 1 marks "hand here" for final.
    /* DRAWBUFFERS:8 */
    gl_FragData[0] = vec4(lit, 1.0);
}
