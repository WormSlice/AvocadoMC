#version 120
// Bloom bright-pass: extract HDR pixels above a luminance threshold -> colortex3.

uniform sampler2D colortex0;   // HDR scene (after SSGI)
varying vec2 texcoord;

#define BLOOM_THRESHOLD 1.30   // [0.70 0.90 1.00 1.15 1.35 1.55 1.80 2.20 3.00]

void main() {
    vec3 c = texture2D(colortex0, texcoord).rgb;
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float k = max(l - BLOOM_THRESHOLD, 0.0);
    vec3 bright = c * (k / max(l, 1e-4));

    /* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(bright, 1.0);
}
