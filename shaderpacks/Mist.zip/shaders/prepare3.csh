// prepare3.csh — voxel light propagation step 3 (read A -> write B). Iris.
#version 430 compatibility
// #define VOXEL_LIGHTING  // voxel disabled (broken); passes now no-op
#include "/lib/voxel.glsl"
layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(1, 1, 1);   // no-op while VOXEL_LIGHTING off (was 16,16,16)
void main() {
#ifdef VOXEL_LIGHTING
    voxelPropagate(0);
#endif
}
