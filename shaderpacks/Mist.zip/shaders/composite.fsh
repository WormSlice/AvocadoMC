#version 120
#include "/lib/common.glsl"
#include "/lib/water.glsl"
// gbuffer.glsl: decodeNormalOct for the metal-reflection normal
#include "/lib/gbuffer.glsl"
// atmosphere.glsl: analyticSkyTint for the NON-screen-space environment reflection
#include "/lib/atmosphere.glsl"

uniform sampler2D gcolor;
uniform sampler2D colortex1;   // rg = oct world normal, b = metallic, a = smoothness
uniform sampler2D colortex2;   // g = skyLight of whatever is under the water (opaque gbuffer)
uniform sampler2D depthtex1;   // opaque depth behind translucents (water bottom)
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform float rainStrength;

#define WATER_SSR          // toggle: screen-space reflections on water
#define WATER_SPECULAR     // toggle: sun/moon specular glint on water
#define WATER_REFRACTION 3.0  // [0.0 0.5 0.8 1.2 1.6 2.2 3.0] underwater distortion strength

#define METAL_SSR             // toggle: screen-space reflections on smooth/metallic opaque surfaces
#define METAL_SSR_STRENGTH 1.0  // [0.0 0.5 0.75 1.0 1.25 1.5] overall metal reflection amount

varying vec2 texcoord;

// Sun/moon world-space direction (matches the deferred lighting convention).
vec3 getWaterLightDir() {
    vec3 sd = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    if (sd.y < 0.0) sd = normalize(mat3(gbufferModelViewInverse) * moonPosition);
    return sd;
}

vec4 waterColor(vec3 color, vec2 texcoord) {
	float depth = getDepth(texcoord);
	vec3 position = getWorldPosition(texcoord, depth);

	// Water thickness (blocks) from surface depth vs the opaque depth behind it.
	float surfDist = linearizeDepth(depth) * far;
	float bottDist = linearizeDepth(texture2D(depthtex1, texcoord).r) * far;
	float thickness = max(bottDist - surfDist, 0.0);

	// Wavy normal for the reflection direction -- safe now because the
	// raytrace itself no longer jumps to scene depth between steps,
	// so small per-pixel normal variation doesn't cause instability.
	vec3 normal = getWaterNormal(position + cameraPosition);
	vec3 viewDir = normalize(position);
	vec3 reflectedDir = normalize(reflect(viewDir, normal));

	float fresnel = getWaterFresnel(viewDir, normal);

	// Sky visibility at this water pixel, taken from the lightmap of whatever
	// opaque surface sits under/around it. Cave water has skyLight ~ 0, so the
	// analytic "sky" reflection/glint below must fade out there -- otherwise
	// underground water reflects a bright, fully-lit sky that isn't actually
	// visible, which is why cave water read as glowing white.
	// NOTE: this is Minecraft's raw lightmap texture coordinate (0=dark lands at
	// 1/32, not 0 -- see lib/lighting.glsl's unpackLightmap), so it must be
	// unpacked the same way or "fully dark" still reads as ~3% sky-lit. Cubed
	// (matches lib/lighting.glsl's skyGate) so a partially sky-connected shaft
	// doesn't still show a near-full bright sky reflection on its water.
	float skyLightRaw = clamp((texture2D(colortex2, texcoord).g - (1.0 / 32.0)) / (30.0 / 32.0), 0.0, 1.0);
	float skyVis = pow(skyLightRaw, 3.0);

	// ---- APPARENT DEPTH (Snell's law) -----------------------------------------
	// Light bends as it leaves the water, so the bottom LOOKS shallower/closer than
	// it really is (the classic "bent stick" / raised-riverbed illusion). Perceived
	// depth = real depth / index-of-refraction, and it compresses MORE at grazing
	// angles. We use this apparent thickness for both the murk build-up (so the
	// bottom reads as nearer) and to pull the refracted sample slightly toward the
	// viewer, raising the bottom on screen.
	const float WATER_IOR = 1.333;
	float cosView   = clamp(dot(-viewDir, normal), 0.0, 1.0);      // 1 = straight down
	float depthComp = mix(2.0, WATER_IOR, cosView);                // grazing looks even shallower
	float apparentThickness = thickness / depthComp;

	// ---- REFRACTION: bend the underwater view by the wave normal --------------
	// Things seen through the surface appear wobbled/displaced (wave lens), plus an
	// apparent-depth parallax that shifts the bottom back toward the surface entry
	// point so it sits closer/higher. Deeper water bends more. We guard against
	// dragging foreground (above-water) pixels into the water.
	float depthRaise = (thickness - apparentThickness) * 0.02;     // how far to pull the bottom up
	vec2  refrOffset = normal.xz * WATER_REFRACTION * 0.045 * clamp(apparentThickness * 0.5, 0.15, 1.0)
	                 - viewDir.xz * depthRaise;                     // parallax toward the viewer
	vec2 refrUV     = clamp(texcoord + refrOffset, vec2(0.002), vec2(0.998));
	if (getDepth(refrUV) < depth) refrUV = texcoord;   // sampled pixel is in front of water
	vec3 underwater = texture2D(gcolor, refrUV).rgb;

	// ---- WATER BODY = the TEXTURED surface color from the forward pass ---------
	// `color` carries the vanilla Minecraft water texture. Deeper water shows more
	// of that textured body; shallow water shows the refracted bottom. This keeps
	// the recognizable water texture visible instead of a flat plastic sheet.
	// Shallow water is now mostly the refracted (rippling) bottom with only a light
	// blue wash; the tint builds with APPARENT depth (Snell) so the bottom reads as
	// nearer, while deep water still darkens to a solid blue body. Lower base
	// (was 0.20) is what lets you actually SEE the sand through a pool.
	float bodyAmount = clamp(apparentThickness * 0.12 + 0.07, 0.0, 0.80);
	underwater = mix(underwater, color, bodyAmount);

	// ---- REFLECTION: the ACTUAL sky in the reflected direction -----------------
	// Reflect the real analytic sky (the SAME model the metal SSR and aerial fog
	// use) so the water automatically picks up sunset warmth, blue noon or overcast
	// grey instead of a fixed blue sheet that ignores the environment. This is the
	// fix for "su ortama uygun davranmıyor": at a pink dusk the water now mirrors
	// that pink, not a hard-coded ocean blue.
	vec3  sunDir  = normalize(mat3(gbufferModelViewInverse) * sunPosition);
	vec3  skyReflection = analyticSkyTint(reflectedDir, sunDir, rainStrength);
	// Tight sun glitter, tinted by the sky's own colour at the sun (warm at dawn/
	// dusk, cool at night) so the highlight matches the environment rather than a
	// flat white sheen.
	float sunCos = max(dot(reflectedDir, sunDir), 0.0);
	vec3  sunTint = analyticSkyTint(sunDir, sunDir, rainStrength) + vec3(0.3);
	skyReflection += sunTint * pow(sunCos, 200.0) * 0.9;
	// Fade to a dim, neutral cave tone where there's no real sky access, so indoor
	// water still shows SOME reflection (from block-light-lit hitColor via SSR).
	skyReflection = mix(vec3(0.05, 0.05, 0.06), skyReflection, skyVis);
	vec3 reflectionColor = skyReflection;

#ifdef WATER_SSR
	vec2 reflectionUV = raytrace(position, reflectedDir);
	if (reflectionUV.x > 0.0) {
		vec2 edge = smoothstep(0.0, 0.08, reflectionUV) * smoothstep(0.0, 0.08, 1.0 - reflectionUV);
		float edgeFade = edge.x * edge.y;
		vec3 hitColor = texture2D(gcolor, reflectionUV).rgb;
		reflectionColor = mix(skyReflection, hitColor, edgeFade);
	}
#endif

	// Fresnel-driven reflectance. Real water is nearly a MIRROR at grazing angles
	// (all the distant river surface you see edge-on) and mostly its own body when
	// you look straight down into it. The old flat 0.55 cap kept even far water
	// blue; letting it climb to ~0.92 at grazing makes distant water take the
	// sky's colour (pink dusk here) as it physically should, while head-on water
	// (0.06) still shows the textured blue body.
	float reflMix = mix(0.06, 0.92, clamp(fresnel, 0.0, 1.0));
	vec3 finalColor = mix(underwater, reflectionColor, reflMix);

	// FOAM was removed: its "thickness" heuristic (opaque depth minus water-
	// surface depth) is unreliable at grazing angles and close range, so the
	// shoreline trim kept reappearing as a bright swirl/blob at the water's near
	// edges and corners no matter how it was gated. Not worth keeping.

#ifdef WATER_SPECULAR
	// Tight sun/moon glint on the wave crests (HDR -> feeds bloom), kept subtle.
	// The glint colour is pulled from the sky at the light direction so it warms at
	// dawn/dusk and cools at night automatically, instead of a fixed white that
	// reads as flat plastic light on the surface.
	vec3  L      = getWaterLightDir();
	vec3  H      = normalize(L - viewDir);
	float spec   = pow(max(dot(normal, H), 0.0), 300.0);
	vec3  sunCol = (L.y > 0.0) ? analyticSkyTint(L, L, rainStrength) + vec3(0.35)
	                           : vec3(0.5, 0.6, 0.85);
	finalColor  += sunCol * spec * 2.0 * fresnel * skyVis;
#endif

	return vec4(finalColor, 1.0);
}

// ---- METAL / GLOSSY SSR (opaque surfaces) ----------------------------------
// Screen-space raytrace, exactly like the water: it mirrors whatever is on
// screen -- blocks, mobs, the player in third person -- and falls back to the
// analytic sky where the ray misses or leaves the screen (so misses fade into
// sky instead of a black hole). Metallic pixels are tinted by the block's own
// color. Driven by the PBR spec map's metallic + smoothness.
vec3 metalReflection(vec3 color, vec2 uv) {
#ifdef METAL_SSR
	float depth = getDepth(uv);
	if (depth >= 1.0) return color;                 // sky: nothing to reflect on

	vec4  g1         = texture2D(colortex1, uv);
	float metallic   = g1.b;
	float smoothness = g1.a;

	float gloss = smoothstep(0.55, 0.95, smoothness);
	if (gloss < 0.02) return color;

	vec3 position = getWorldPosition(uv, depth);    // eye-relative (player) space
	vec3 N        = decodeNormalOct(g1.rg);         // world-space normal
	vec3 viewDir  = normalize(position);
	vec3 reflDir  = normalize(reflect(viewDir, N));

	// Fresnel: dielectrics jump from ~0.04 head-on to ~1.0 at grazing; metals
	// stay high everywhere. mix() by metalness blends between those.
	float NdotV = max(dot(N, -viewDir), 0.0);
	float fres  = pow(1.0 - NdotV, 5.0);
	float metal = clamp(metallic, 0.0, 1.0);
	float refl  = gloss * mix(0.04 + 0.96 * fres, 1.0, metal);
	float k     = clamp(refl * METAL_SSR_STRENGTH, 0.0, 0.6);
	if (k < 0.02) return color;

	// Sky fallback for rays that miss / leave the screen (gated by real sky
	// access so a cave metal doesn't fall back to a bright sky).
	vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * sunPosition);
	vec3 env    = analyticSkyTint(reflDir, sunDir, rainStrength);
	float sl    = clamp((texture2D(colortex2, uv).g - (1.0 / 32.0)) / (30.0 / 32.0), 0.0, 1.0);
	env = mix(vec3(0.05, 0.05, 0.06), env, pow(sl, 3.0));

	// SCREEN-SPACE raytrace: reflect the actual scene (incl. entities). Blend to
	// the sky fallback at the screen borders so on-screen hits don't hard-cut.
	vec3 reflColor = env;
	vec2 rUV = raytrace(position, reflDir);
	if (rUV.x > 0.0) {
		vec2  edge     = smoothstep(0.0, 0.08, rUV) * smoothstep(0.0, 0.08, 1.0 - rUV);
		float edgeFade = edge.x * edge.y;
		vec3  hit      = texture2D(gcolor, rUV).rgb;
		reflColor = mix(env, hit, edgeFade);
	}

	// Tint by the block's own hue for the metallic part (gold -> golden, diamond
	// -> cyan). Brightness-normalized so tinting shifts hue without darkening.
	float lum  = max(dot(color, vec3(0.2126, 0.7152, 0.0722)), 0.04);
	vec3  tint = mix(vec3(1.0), color / lum, metal);
	reflColor *= tint;

	return mix(color, reflColor, k);
#else
	return color;
#endif
}

void main() {
	vec3 color = texture2D(gcolor, texcoord).rgb;

	vec4 outColor = vec4(color, 1.0);
	if (isWater(texcoord) && isEyeInWater == 0)
		outColor = waterColor(color, texcoord);
	else if (isEyeInWater == 0)
		outColor.rgb = metalReflection(color, texcoord);   // opaque metal/glossy SSR

	/* DRAWBUFFERS:0 */
	gl_FragData[0] = outColor; //gcolor
}