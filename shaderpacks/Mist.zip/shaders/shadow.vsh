// shadow.vsh — shadow map + carries world pos & block id for voxelization (Iris).
#version 430 compatibility

// #define VOXEL_LIGHTING  // voxel disabled (broken); passes now no-op

attribute vec4 mc_Entity;

varying vec2  lmcoord;
varying vec2  texcoord;
varying vec4  glcolor;
varying vec3  vWorldAbs;
varying float vBlockId;

uniform mat4 shadowModelViewInverse;
uniform vec3 cameraPosition;

#include "/distort.glsl"

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    vBlockId = mc_Entity.x;

    // Absolute world position (for the voxel write in the fragment shader).
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vWorldAbs = (shadowModelViewInverse * viewPos).xyz + cameraPosition;

    #ifdef EXCLUDE_FOLIAGE
        if (mc_Entity.x == 10000.0) {
            gl_Position = vec4(111.0); // cull foliage from shadow map (and voxel)
            return;
        }
    #endif

    gl_Position = ftransform();
    gl_Position.xyz = distort(gl_Position.xyz);
}
