// deferred1.vsh — fullscreen vertex shader for the voxel-light resolve (Iris 430).
#version 430 compatibility
out vec2 texcoord;
void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
