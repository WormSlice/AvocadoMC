#version 120

// ============================================================================
//  deferred2.fsh — DEFERRED LIGHTING (was deferred1). Runs after deferred (SSAO)
//  and deferred1 (voxel light resolve -> colortex4). Uses voxel colored block
//  light when VOXEL_LIGHTING is on (occluded, colored), else the omni fallback.
// ============================================================================

// VOXEL_LIGHTING removed: the voxel colored-light path was broken, so lighting
// now always uses the stable omni block-light fallback (blockLightBRDF).

uniform sampler2D gcolor;     // colortex0 : albedo
uniform sampler2D colortex1;  // rg=oct normal, b=metallic, a=smoothness
uniform sampler2D colortex2;  // r=blockLight, g=skyLight, b=emissive, a=lit flag
uniform sampler2D colortex4;  // rgb = resolved voxel block light (Iris voxel GI)
uniform sampler2D colortex6;  // r = SSAO
uniform sampler2D depthtex0;

uniform mat4 gbufferProjectionInverse;

varying vec2 texcoord;

#include "/lib/gbuffer.glsl"
#include "/lib/lighting.glsl"

vec3 getPlayerPos(vec2 uv, float depth) {
    vec3 ndc = vec3(uv, depth) * 2.0 - 1.0;
    vec4 vw  = gbufferProjectionInverse * vec4(ndc, 1.0);
    vec3 viewPos = vw.xyz / vw.w;
    return (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
}

float vlJitter(vec2 uv) {
    return fract(sin(dot(uv, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec3 albedo = texture2D(gcolor, texcoord).rgb;
    vec4 g1 = texture2D(colortex1, texcoord);
    vec4 g2 = texture2D(colortex2, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;

    vec3 outColor = albedo;
    vec3 playerPos = getPlayerPos(texcoord, depth);

    if (g2.a > 0.5 && depth < 1.0) {
        vec3  N          = decodeNormalOct(g1.rg);
        float metallic   = g1.b;
        float roughness  = clamp(1.0 - g1.a, 0.04, 1.0);
        float blockLight = g2.r;
        float skyLight   = g2.g;
        float emissive   = g2.b;

        gAO = texture2D(colortex6, texcoord).r;   // SSAO into ambient

#ifdef VOXEL_LIGHTING
        gUseVoxelLight   = true;                  // colored, occluded block light
        gVoxelBlockLight = texture2D(colortex4, texcoord).rgb;
#endif

        vec3 lit = computeSceneLighting(albedo, N, playerPos,
                                        blockLight, skyLight,
                                        metallic, roughness, emissive);

        lit = applySceneFog(lit, playerPos, skyLight);
        outColor = lit;
    }

    // Volumetric god rays belong in the AIR. On open sky (depth==1.0) add them at
    // full strength; over solid geometry (terrain, mobs, entities) damp the
    // additive in-scatter hard so a mob standing in front of the sun isn't washed
    // bright and read as see-through. Keeps a little atmospheric depth on distant
    // surfaces without painting the shaft over what should be opaque.
    float vlSurf = (depth >= 1.0) ? 1.0 : 0.35;
    outColor += volumetricLight(playerPos, vlJitter(texcoord)) * vlSurf;

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(outColor, 1.0);
}
