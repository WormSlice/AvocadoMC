#version 120

attribute vec4 mc_Entity;

varying vec2 lmcoord;
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 worldPos;
varying vec3 worldNormal;
varying float isWaterFlag;   // 1.0 only for real water; 0.0 for glass/ice/etc.

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

void main() {
	gl_Position = ftransform();
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;

	// The translucent program draws ALL translucents (water, glass, ice...).
	// Only block ids 10001/10002 (water/bubble) get the water treatment.
	float id = mc_Entity.x;
	isWaterFlag = (id == 10001.0 || id == 10002.0 || id == 8.0 || id == 9.0) ? 1.0 : 0.0;

	// World-space position (for wave animation) + geometric world normal.
	vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
	worldPos = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;
	worldNormal = normalize(mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal));
}
