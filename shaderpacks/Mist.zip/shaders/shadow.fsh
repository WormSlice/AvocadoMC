// shadow.fsh — writes the shadow color AND voxelizes (solid + emitter) to SSBO.
#version 430 compatibility

// #define VOXEL_LIGHTING  // voxel disabled (broken); passes now no-op

uniform sampler2D gtexture;
uniform vec3 cameraPosition;

varying vec2  texcoord;
varying vec4  glcolor;
varying vec3  vWorldAbs;
varying float vBlockId;

#include "/lib/voxel.glsl"

void main() {
    vec4 color = texture(gtexture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

#ifdef VOXEL_LIGHTING
    ivec3 c = worldToVoxel(vWorldAbs, cameraPosition);
    if (voxelInBounds(c)) {
        // Emitter ids: 10010 (strong sources) + 10011 (decorative glow: redstone
        // / lapis). Emitters store a VALUE-NORMALIZED hue so even dark textures
        // (redstone red, lapis blue) emit a saturated colored light at full
        // brightness. Matte blocks store their ALBEDO so the bounce can tint by
        // the surface color (bright block -> colored spill onto dull blocks).
        bool emitter = (vBlockId > 10009.5 && vBlockId < 10011.5);
        vec3 vox;
        if (emitter) {
            float m = max(max(color.r, color.g), color.b);
            vox = color.rgb / max(m, 0.20);     // saturated hue, full value
        } else {
            vox = color.rgb;                    // albedo for matte bounce
        }
        atomicOr(uVoxel[voxelIndex(c)], packVoxel(true, emitter, vox));
    }
#endif

    /* DRAWBUFFERS:01 */
    gl_FragData[0] = color;                 // shadowcolor0
    gl_FragData[1] = vec4(vec3(1.0), 1.0);  // shadowcolor1
}
