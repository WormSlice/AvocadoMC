// ============================================================
//  GoldenHour Shaders — distort.glsl
//  PCSS + 32-sample Poisson PCF soft shadows
// ============================================================

#define SHADOW_DISTORT_ENABLED
#define SHADOW_DISTORT_FACTOR 0.08  //[0.00 0.01 0.03 0.05 0.08 0.10 0.12 0.15 0.20]
#define SHADOW_BIAS           1.00  //[0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.50 15.00]
// NORMAL_BIAS disabled (opam.txt: NORMAL_BIAS=false)
// EXCLUDE_FOLIAGE disabled (opam.txt: EXCLUDE_FOLIAGE=false)
#define SHADOW_BRIGHTNESS     0.40  //[0.20 0.30 0.40 0.50 0.60 0.70]

// Shadow map resolution
const int shadowMapResolution = 2048; //[512 1024 2048 4096 8192 16384]

// ============================================================
//  GÖLGE YUMUŞATMA (Shadow Softening)
//
//  SHADOW_SOFTNESS  — Ana blur yarıçapı. 0 = keskin, yükseği = daha yumuşak.
//                     0.0006 civarı doğal, 0.002 çok yumuşak.
//  SHADOW_SAMPLES   — PCF örnek sayısı. Fazlası = daha pürüzsüz ama ağır.
//                     16 hafif, 32 dengeli, 64 kaliteli.
//  PCSS_ENABLED     — Gölge uzaklığa göre yumuşar (gerçekçi penumbra).
//                     Kapatırsanız sabit SHADOW_SOFTNESS uygulanır.
//  PCSS_LIGHT_ANGLE — Güneşin açısal büyüklüğü. Büyüğü = daha geniş penumbra.
//                     0.02 gerçekçi, 0.08 çok yayılmış.
//  PCSS_SEARCH_R    — Blocker arama yarıçapı. SHADOW_SOFTNESS ile orantılı olsun.
// ============================================================

#define SHADOW_SOFTNESS   0.0010   // [0.0000 0.0002 0.0004 0.0006 0.0008 0.0010 0.0012 0.0016 0.0020 0.0028 0.0040 0.0060 0.0090 0.0120]
#define SHADOW_SAMPLES    16       // [8 12 16 24 32 48 64]
#define PCSS_ENABLED               // Uzaklığa göre yumuşama — kapat = sabit blur
#define PCSS_LIGHT_ANGLE  0.005   // [0.005 0.010 0.015 0.020 0.025 0.030 0.035 0.040 0.050 0.065 0.080 0.100]
#define PCSS_SEARCH_R     0.0000  // [0.0000 0.0010 0.0020 0.0030 0.0040 0.0060 0.0080 0.0100 0.0140]

// Geri uyumluluk takma adları (eski kod referansları için)
#define PCF_SAMPLES      1
#define PCF_MIN_RADIUS   SHADOW_SOFTNESS
#define PCF_MAX_RADIUS   0
// #define PCF_MAX_RADIUS   (SHADOW_SOFTNESS * 6.0)

// Warm block-light tint (torch / lava / glowstone). Kept WARM but not a pure
// saturated orange -- the old (1.0,0.62,0.20) painted every torch-lit room a
// flat monochrome orange that erased texture color and contrast. A warm-white
// lets block textures keep their own hue so the scene reads with depth.
#define BLOCKLIGHT_R 1.00
#define BLOCKLIGHT_G 0.83
#define BLOCKLIGHT_B 0.60

// ---- Elde tutulan item ID'leri (OptiFine/Iris heldItemId) ----
// Crying Obsidian
#define ITEM_CRYING_OBSIDIAN   246
// Soul Torch + Soul Lantern
#define ITEM_SOUL_TORCH        776
#define ITEM_SOUL_LANTERN      523
// Copper Torch (Minecraft 1.21+)
#define ITEM_COPPER_TORCH      1049
#define ITEM_COPPER_BULB       1038
// Normal Torch (referans)
#define ITEM_TORCH             50

// Elde tutulan item'a göre ışık rengi döndür
// heldItemId: OptiFine uniform (int)
// heldLv: heldBlockLightValue 0-15
// Döndürür: HDR light color (>1.0 olabilir, bloom besler)
vec3 heldLightColor(int itemId, int itemId2, float heldLv) {
    // Crying Obsidian — mor/pembe
    if (itemId == ITEM_CRYING_OBSIDIAN || itemId2 == ITEM_CRYING_OBSIDIAN)
        return vec3(0.72, 0.10, 1.00) * (heldLv / 3.0);
    // Soul Torch / Soul Lantern — soğuk mavi-yeşil
    if (itemId == ITEM_SOUL_TORCH   || itemId2 == ITEM_SOUL_TORCH   ||
        itemId == ITEM_SOUL_LANTERN || itemId2 == ITEM_SOUL_LANTERN)
        return vec3(0.12, 0.55, 1.00) * (heldLv / 15.0);
    // Copper Torch / Copper Bulb — yeşilimsi
    if (itemId == ITEM_COPPER_TORCH || itemId2 == ITEM_COPPER_TORCH ||
        itemId == ITEM_COPPER_BULB  || itemId2 == ITEM_COPPER_BULB)
        return vec3(0.20, 0.85, 0.30) * (heldLv / 15.0);
    // Varsayılan: sıcak turuncu (torch/lava/glowstone)
    return vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B) * (heldLv / 15.0);
}

// Sunlight warm tint
#define SUNLIGHT_R 1.00
#define SUNLIGHT_G 1.32
#define SUNLIGHT_B 0.75

// ---- distortion ----

#ifdef SHADOW_DISTORT_ENABLED
    vec3 distort(vec3 pos) {
        float factor = length(pos.xy) + SHADOW_DISTORT_FACTOR;
        return vec3(pos.xy / factor, pos.z * 0.5);
    }
    float computeBias(vec3 pos) {
        float n = length(pos.xy) + SHADOW_DISTORT_FACTOR;
        n *= n;
        return SHADOW_BIAS / float(shadowMapResolution) * n / SHADOW_DISTORT_FACTOR;
    }
#else
    vec3 distort(vec3 pos) { return vec3(pos.xy, pos.z * 0.5); }
    float computeBias(vec3 pos) { return SHADOW_BIAS / float(shadowMapResolution); }
#endif

// ---- 32-sample Poisson disk ----
// Spread evenly so all 32 are used; no array init loop needed.
vec2 poisson32(int i) {
    // Hand-crafted Poisson disk, radius ~1, 32 points
    if (i ==  0) return vec2(-0.6130,  0.7427);
    if (i ==  1) return vec2( 0.3555,  0.8888);
    if (i ==  2) return vec2( 0.9430,  0.2456);
    if (i ==  3) return vec2( 0.7668, -0.5168);
    if (i ==  4) return vec2( 0.1227, -0.9766);
    if (i ==  5) return vec2(-0.4236, -0.8421);
    if (i ==  6) return vec2(-0.9604, -0.1729);
    if (i ==  7) return vec2(-0.8768,  0.4127);
    if (i ==  8) return vec2(-0.1891,  0.3651);
    if (i ==  9) return vec2( 0.5018,  0.4619);
    if (i == 10) return vec2( 0.2985, -0.3876);
    if (i == 11) return vec2(-0.3912,  0.0285);
    if (i == 12) return vec2(-0.0563, -0.3205);
    if (i == 13) return vec2( 0.6813, -0.0421);
    if (i == 14) return vec2(-0.7142, -0.5533);
    if (i == 15) return vec2( 0.0245,  0.9971);
    if (i == 16) return vec2(-0.2764,  0.9310);
    if (i == 17) return vec2( 0.8411,  0.5134);
    if (i == 18) return vec2( 0.5543, -0.8065);
    if (i == 19) return vec2(-0.5091, -0.4428);
    if (i == 20) return vec2( 0.1483,  0.0678);
    if (i == 21) return vec2(-0.8432,  0.1064);
    if (i == 22) return vec2( 0.4231, -0.0934);
    if (i == 23) return vec2(-0.1741, -0.6887);
    if (i == 24) return vec2( 0.9027, -0.3011);
    if (i == 25) return vec2(-0.3504,  0.5849);
    if (i == 26) return vec2( 0.0771, -0.6271);
    if (i == 27) return vec2( 0.6537,  0.7419);
    if (i == 28) return vec2(-0.7855, -0.2742);
    if (i == 29) return vec2( 0.3209,  0.2134);
    if (i == 30) return vec2(-0.1023,  0.6583);
    if (i == 31) return vec2( 0.7723, -0.1832);
    return vec2(1.0);
}

// ---- PCSS: blocker search ----
// Returns average blocker depth (or -1 if no blocker found)
float findBlockerDepth(sampler2D shadowMap, vec2 uv, float receiverDepth) {
    float totalDepth = 0.0;
    int   blockers   = 0;
    for (int i = 0; i < 16; i++) {
        vec2 offset   = poisson32(i) * PCSS_SEARCH_R;
        float depth   = texture2D(shadowMap, uv + offset).r;
        if (depth < receiverDepth - 0.0001) {
            totalDepth += depth;
            blockers++;
        }
    }
    return (blockers > 0) ? totalDepth / float(blockers) : -1.0;
}

// ---- Ana PCF + isteğe bağlı PCSS ----
// Döndürür: 0.0 = tam gölge, 1.0 = tam aydınlık
float sampleShadowPCF(sampler2D shadowMap, vec3 shadowCoord) {
    float receiverDepth = shadowCoord.z;

    // Temel yarıçap (kullanıcı ayarı)
    float radius = SHADOW_SOFTNESS;

#ifdef PCSS_ENABLED
    // PCSS: blocker mesafesine göre penumbra genişliği hesapla
    float avgBlocker = findBlockerDepth(shadowMap, shadowCoord.xy, receiverDepth);

    if (avgBlocker > 0.0) {
        // Penumbra: (alıcı - engelleyen mesafe) × ışık açısı
        float penumbra = (receiverDepth - avgBlocker) * PCSS_LIGHT_ANGLE / avgBlocker;
        // Kullanıcı ayarını minimum sınır olarak kullan
        radius = clamp(penumbra, SHADOW_SOFTNESS, SHADOW_SOFTNESS * 6.0);
    } else {
        // Blocker yok = tamamen aydınlık, hızlı çık
        return 1.0;
    }
#else
    // PCSS kapalı: sabit blur radius, hızlı tam aydınlık kontrolü
    float centerDepth = texture2D(shadowMap, shadowCoord.xy).r;
    if (centerDepth >= receiverDepth - 0.0001 && radius < 0.00005) return 1.0;
#endif

    // Poisson PCF — SHADOW_SAMPLES adet örnek
    float lit = 0.0;
    float bias = 0.0001;
    int shadowSamples = int(SHADOW_SAMPLES);
    for (int i = 0; i < shadowSamples; i++) {
        vec2  offset = poisson32(i) * radius;
        float depth  = texture2D(shadowMap, shadowCoord.xy + offset).r;
        lit += (depth > receiverDepth - bias) ? 1.0 : 0.0;
    }
    return lit / float(shadowSamples);
}
