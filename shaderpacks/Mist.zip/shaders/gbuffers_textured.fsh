#version 120

// ============================================================================
//  gbuffers_textured.fsh — particles, item frames, etc.
//  These can be drawn in the translucent (post-deferred) phase, so they are
//  forward-lit here with the SAME lib/lighting.glsl model, and the deferred
//  lighting flag is cleared so opaque ones are not double-lit.
// ============================================================================

#include "/lib/lighting.glsl"
#include "/lib/gbuffer.glsl"

uniform sampler2D texture;
uniform sampler2D normals;
uniform sampler2D specular;

// Hurt/death flash tint. OptiFine/Iris set this per entity: rgb = the overlay
// color (red when damaged, white on death), a = how strongly to apply it. For
// non-entity draws (particles, item frames) it stays (0,0,0,0) -> no effect.
uniform vec4 entityColor;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldNormal;
varying vec4 worldTangent;
varying vec3 worldPos;
varying vec3 viewPos;

vec3 applyNormalMap(vec3 N, vec4 T, vec2 uv) {
    vec3 sampleN = texture2D(normals, uv).rgb;
    if (length(sampleN - vec3(0.5)) < 0.02) return normalize(N);

    vec3 nm;
    nm.xy = sampleN.xy * 2.0 - 1.0;
    nm.z  = sqrt(max(1.0 - dot(nm.xy, nm.xy), 0.0));

    vec3 tangent   = normalize(T.xyz);
    vec3 bitangent = normalize(cross(N, tangent) * T.w);
    mat3 tbn = mat3(tangent, bitangent, normalize(N));
    return normalize(tbn * nm);
}

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    // Vanilla hurt/death flash: blend the mob's albedo toward the flash color
    // before lighting, so the red tint is shaded with the entity instead of
    // sitting on top as a flat decal.
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);

    vec3 playerPos = worldPos - cameraPosition;
    vec3 N = applyNormalMap(worldNormal, worldTangent, texcoord);
    Material mat = getMaterial(specular, texcoord, color.rgb);

    vec3 lit = computeSceneLighting(color.rgb, N, playerPos,
                                    lmcoord.x, lmcoord.y,
                                    mat.metallic, clamp(1.0 - mat.smoothness, 0.04, 1.0),
                                    mat.emissive);

    if (isEyeInWater != 1) {
        lit = applySceneFog(lit, playerPos, lmcoord.y);
    }

    /* DRAWBUFFERS:02 */
    gl_FragData[0] = vec4(lit, color.a);   // gcolor
    gl_FragData[1] = vec4(0.0);            // colortex2 — clear deferred lighting flag
}
