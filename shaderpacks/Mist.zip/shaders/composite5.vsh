#version 120
// Fullscreen pass vertex shader (auto-exposure luminance metering).
varying vec2 texcoord;
void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
