#version 120

// ============================================================================
//  deferred.fsh — SSAO PASS (runs before deferred1 lighting)
//  Screen-space ambient occlusion from depth + world normal. Output r=AO into
//  colortex6; the lighting pass multiplies the sky-ambient term by it. View-
//  space hemisphere sampling (Crysis-style) with a per-pixel rotation.
// ============================================================================

uniform sampler2D depthtex0;
uniform sampler2D colortex1;        // rg = oct world normal
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

#include "/lib/gbuffer.glsl"

#define SSAO                         // toggle: ambient occlusion
#define SSAO_SAMPLES   10            // [6 8 10 14 20 28]
#define SSAO_RADIUS    0.3           // [0.3 0.5 0.7 1.0 1.4 2.0]
#define SSAO_STRENGTH  1.0           // [0.5 0.8 1.0 1.4 1.8 2.4 3.0]

// Dave Hoskins hashes (work in GLSL 120).
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
vec3 hash33(vec3 p3) {
    p3 = fract(p3 * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yxz + 33.33);
    return fract((p3.xxy + p3.yxx) * p3.zyx);
}

vec3 viewFromDepth(vec2 uv, float d) {
    vec3 ndc = vec3(uv, d) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * vec4(ndc, 1.0);
    return v.xyz / v.w;
}

void main() {
    float depth = texture2D(depthtex0, texcoord).r;
    float ao = 1.0;

#ifdef SSAO
    if (depth < 1.0) {
        vec3 vpos = viewFromDepth(texcoord, depth);
        vec3 wN   = decodeNormalOct(texture2D(colortex1, texcoord).rg);
        vec3 n    = normalize(mat3(gbufferModelView) * wN);

        float rnd = hash12(texcoord * vec2(viewWidth, viewHeight));
        float occ = 0.0;

        for (int i = 0; i < SSAO_SAMPLES; i++) {
            vec3 d = normalize(hash33(vec3(texcoord, float(i) + rnd)) * 2.0 - 1.0);
            if (dot(d, n) < 0.0) d = -d;                     // flip into the hemisphere
            float r = SSAO_RADIUS * (0.3 + 0.7 * float(i) / float(SSAO_SAMPLES));
            vec3 sp = vpos + d * r;

            vec4 clip = gbufferProjection * vec4(sp, 1.0);
            if (clip.w <= 0.0001) continue;                  // behind/at camera plane -> skip (no streak)
            vec2 suv  = clip.xy / clip.w * 0.5 + 0.5;
            if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;

            float sd = texture2D(depthtex0, suv).r;
            if (sd >= 1.0) continue;
            vec3 svpos = viewFromDepth(suv, sd);

            // Occluded if the real surface at suv is closer to the camera than
            // our sample point (view-space z is negative toward the camera).
            float rangeCheck = SSAO_RADIUS / max(abs(vpos.z - svpos.z), 1e-4);
            rangeCheck = clamp(rangeCheck, 0.0, 1.0);
            if (svpos.z > sp.z + 0.02) occ += rangeCheck;
        }

        ao = 1.0 - (occ / float(SSAO_SAMPLES)) * SSAO_STRENGTH;
        ao = clamp(ao, 0.0, 1.0);
    }
#endif

    /* DRAWBUFFERS:6 */
    gl_FragData[0] = vec4(ao, 0.0, 0.0, 1.0);
}
