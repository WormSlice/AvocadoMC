#version 120

attribute vec4 at_tangent;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldNormal;
varying vec4 worldTangent;
varying vec3 worldPos;
varying vec3 viewPos;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    vec3 viewNormal  = normalize(gl_NormalMatrix * gl_Normal);
    vec3 viewTangent = normalize(gl_NormalMatrix * at_tangent.xyz);
    worldNormal  = normalize(mat3(gbufferModelViewInverse) * viewNormal);
    worldTangent = vec4(normalize(mat3(gbufferModelViewInverse) * viewTangent), at_tangent.w);

    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    viewPos  = viewPosition.xyz;
    worldPos = (gbufferModelViewInverse * viewPosition).xyz + cameraPosition;

    gl_Position = gl_ProjectionMatrix * viewPosition;
}
