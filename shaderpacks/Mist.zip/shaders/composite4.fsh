#version 120
// Bloom separable Gaussian — VERTICAL pass. colortex3 -> colortex3.

uniform sampler2D colortex3;
uniform float viewHeight;
varying vec2 texcoord;

#define BLOOM_RADIUS 3.0   // [1.0 1.5 2.0 2.5 3.0 4.0]

void main() {
    vec2 px = vec2(0.0, BLOOM_RADIUS / viewHeight);

    vec3 c = texture2D(colortex3, texcoord).rgb * 0.2270270270;
    c += texture2D(colortex3, texcoord + px * 1.0).rgb * 0.1945945946;
    c += texture2D(colortex3, texcoord - px * 1.0).rgb * 0.1945945946;
    c += texture2D(colortex3, texcoord + px * 2.0).rgb * 0.1216216216;
    c += texture2D(colortex3, texcoord - px * 2.0).rgb * 0.1216216216;
    c += texture2D(colortex3, texcoord + px * 3.0).rgb * 0.0540540541;
    c += texture2D(colortex3, texcoord - px * 3.0).rgb * 0.0540540541;
    c += texture2D(colortex3, texcoord + px * 4.0).rgb * 0.0162162162;
    c += texture2D(colortex3, texcoord - px * 4.0).rgb * 0.0162162162;

    /* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(c, 1.0);
}
