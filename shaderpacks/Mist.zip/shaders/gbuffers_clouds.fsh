#version 120

// ============================================================================
//  gbuffers_clouds.fsh   (Stage 4)
//
//  Minecraft's vanilla cloud mesh is a flat, blocky layer. We render our own
//  volumetric cloud layer in the sky pass (gbuffers_skybasic ->
//  renderCloudLayer), so here we simply DISCARD the vanilla cloud geometry to
//  stop the two from drawing on top of each other. Toggle CLOUDS off to fall
//  back to vanilla clouds unchanged.
// ============================================================================

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

#include "/lib/atmosphere.glsl"

void main() {
#ifdef CLOUDS
    discard;   // custom clouds drawn in the sky pass instead
#else
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = texture2D(texture, texcoord) * glcolor;
#endif
}
