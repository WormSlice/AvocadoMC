#version 120

// ============================================================================
//  gbuffers_water.fsh — translucent program (water + glass/ice/etc.)
//  OptiFine routes ALL translucent blocks through here. Real water (isWaterFlag)
//  gets wave normals, water tint and the water mask (so the composite pass adds
//  reflections/refraction). Everything else (stained glass, ice, slime...) is
//  rendered as a plain lit translucent and is explicitly NOT flagged as water.
// ============================================================================

#include "/lib/lighting.glsl"
#include "/lib/water.glsl"

uniform sampler2D texture;

varying vec2 lmcoord;
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 worldPos;
varying vec3 worldNormal;
varying float isWaterFlag;

void main() {
    vec3 playerPos = worldPos - cameraPosition;
    vec4 texColor  = texture2D(texture, texcoord) * glcolor;

    if (isWaterFlag > 0.5) {
        // ---- REAL WATER --------------------------------------------------
        vec3  N = normalize(getWaterNormal(worldPos));
        vec3  V = normalize(-playerPos);
        // Grazing angles become more opaque/reflective (Schlick fresnel). The old
        // clamp(x, 0.0, 0.0) pinned this to 0 so water alpha never responded to
        // view angle. Clamp to [0,1] so the term is live again.
        float fresnel = pow(clamp(1.0 - max(dot(V, N), 0.0), 0.0, 1.0), WATER_FRESNEL_POWER);

        // Show the vanilla Minecraft water TEXTURE prominently (its animated
        // ripple highlights are what stop the surface looking like flat plastic),
        // tinted by the water base color.
        vec4 color = WATER_COLOR;
        color.rgb = mix(color.rgb, texColor.rgb * 0.90, 1.0);
        color.a   = mix(color.a, 1.0, fresnel);

        // Seen from BELOW (submerged), the surface should read as a thin, mostly
        // see-through membrane — you look UP through it at the bright above-water /
        // Snell window — not an opaque blue lid. Drop its opacity hard so the sky
        // shows through instead of a flat tinted ceiling.
        if (isEyeInWater == 1) color.a *= 0.50;

        // Water is a smooth non-metallic dielectric with NO self-emission. The old
        // call passed metallic=3.3 (out of range -> negative ambient) and
        // emissive=2.0, which made water glow ~4x its albedo independently of the
        // surroundings — that is why cave water was blindingly bright. Correct
        // values: metallic 0, low roughness, zero emission. Cave water is now dark
        // unless actually lit by a torch or the sky (reflections still come from
        // the composite SSR pass via the water mask below).
        vec3 lit = computeSceneLighting(color.rgb, N, playerPos,
                                        lmcoord.x, lmcoord.y, 0.0, 0.05, 0.0);

        if (isEyeInWater != 1)
            lit = applySceneFog(lit, playerPos, lmcoord.y);

        /* DRAWBUFFERS:05 */
        gl_FragData[0] = vec4(lit, color.a);
        gl_FragData[1] = vec4(vec3(gl_FragCoord.z), 1);  // a=1 -> water
    } else {
        // ---- GLASS / ICE / OTHER TRANSLUCENT -----------------------------
        if (texColor.a < 0.05) discard;

        // Glass/ice are smooth & non-metallic. Use the real geometric normal.
        vec3 lit = computeSceneLighting(texColor.rgb, normalize(worldNormal), playerPos,
                                        lmcoord.x, lmcoord.y, 0.0, 0.30, 0.0);

        if (isEyeInWater != 1)
            lit = applySceneFog(lit, playerPos, lmcoord.y);

        /* DRAWBUFFERS:05 */
        gl_FragData[0] = vec4(lit, texColor.a);
        gl_FragData[1] = vec4(0.0);                        // a=0 -> NOT water
    }
}
