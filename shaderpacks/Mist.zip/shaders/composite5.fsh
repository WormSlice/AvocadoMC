#version 120

// ============================================================================
//  composite5.fsh — AUTO EXPOSURE / EYE ADAPTATION metering.
//  Computes the scene's geometric-mean luminance from a coarse grid, smooths it
//  toward the previous frame's value (stored in colortex7, not cleared), and
//  writes the adapted luminance. final.fsh turns it into an exposure multiplier.
// ============================================================================

uniform sampler2D colortex0;   // HDR scene (after SSGI)
uniform sampler2D colortex7;   // previous adapted luminance
varying vec2 texcoord;

#define EXPOSURE_SPEED 0.010   // [0.010 0.020 0.045 0.080 0.150 0.300] adaptation speed/frame

void main() {
    // Geometric mean (average of log luminance) over a 12x12 grid. Denser than
    // the old 8x8 so the mean is steadier as the camera moves (fewer, sparser
    // taps = more frame-to-frame jump = flicker).
    float sumLog = 0.0;
    const int N = 12;
    for (int x = 0; x < N; x++) {
        for (int y = 0; y < N; y++) {
            vec2 uv = (vec2(float(x), float(y)) + 0.5) / float(N);
            vec3 c  = texture2D(colortex0, uv).rgb;
            float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
            // Clamp BOTH ends: the floor stops dark pixels dragging the mean to
            // extremes; the CEILING stops a bright torch/lava/ore-glow/sun that
            // sweeps through a sample from spiking the mean (the flicker source).
            l = clamp(l, 0.06, 3.0);
            sumLog += log(l);
        }
    }
    float current = clamp(exp(sumLog / float(N * N)), 0.05, 1.5);

    float prev = texture2D(colortex7, vec2(0.5)).r;
    if (prev <= 0.0) prev = current;            // first frame

    // Smooth, symmetric adaptation. Adapt a touch faster when going darker than
    // brighter (matches the eye), but both are gentle so changes glide instead
    // of snapping. EXPOSURE_SPEED is the base per-frame rate (slider).
    float rate = (current < prev) ? EXPOSURE_SPEED * 1.4 : EXPOSURE_SPEED;
    rate = clamp(rate, 0.0, 1.0);
    float adapted = mix(prev, current, rate);

    /* DRAWBUFFERS:7 */
    gl_FragData[0] = vec4(adapted, 0.0, 0.0, 1.0);
}
